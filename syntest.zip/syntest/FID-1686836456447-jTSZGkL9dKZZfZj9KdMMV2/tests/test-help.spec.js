describe('help', () => {
	const {Help} = require("../../benchmark/commanderjs/lib/help.js");

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:15:2:::19:3:::571:686
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:28:2:::46:3:::877:1634
		const _Help_object_lFnn = new Help()
		const _anon_string_jAFn = "80S5TFSyCUFND2pXdAIXoJFVVDa4xrHyIH5VWzZWGz78AHfezFw1dIL4OesNknHJBbRHxeMTbm";
		const _filter_array_uMyG = [_anon_string_jAFn]
		const _commands_object_rVJi = {
			"filter": _filter_array_uMyG
	}
		const __hasImplicitHelpCommand_function_iCxr = () => { };
		const _match_function_YeJB = () => { };
		const __helpCommandnameAndArgs_object_rmPp = {
			"match": _match_function_YeJB
	}
		const _createCommand_function_mFyf = () => { };
		const __helpCommandDescription_numeric_oLZG = 8.331250640398025;
		const _cmd_object_qMii = {
			"commands": _commands_object_rVJi,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_function_iCxr,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_object_rmPp,
		"createCommand": _createCommand_function_mFyf,
		"_helpCommandDescription": __helpCommandDescription_numeric_oLZG
	}
		const _visibleCommands_function_XuDP = await _Help_object_lFnn.visibleCommands(_cmd_object_qMii)
		const _description_function_FVsZ = () => { };
		const _cmd_object_RsGz = {
			"description": _description_function_FVsZ
	}
		const _commandDescription_function_MATV = await _Help_object_lFnn.commandDescription(_cmd_object_RsGz)
		const _description_null_ptmP = null;
		const _cmd_object_Jgbt = {
			"description": _description_null_ptmP
	}
		const _subcommandDescription_function_mtVb = await _Help_object_lFnn.subcommandDescription(_cmd_object_Jgbt)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:293:2:::343:3:::8421:10245
		const _Help_object_yZbD = new Help()
		const _cmd_null_oJEK = null;
		const _padWidth_function_cSON = () => { };
		const _helpWidth_numeric_pVYR = -0.778678490589158;
		const _wrap_function_cdgS = () => { };
		const _commandUsage_function_Hcuh = () => { };
		const _commandDescription_function_jUaj = () => { };
		const _visibleArguments_function_QCIH = () => { };
		const _argumentTerm_function_rdLC = () => { };
		const _argumentDescription_function_kbqi = () => { };
		const _visibleOptions_function_eSyn = () => { };
		const _optionTerm_function_tLbs = () => { };
		const _optionDescription_boolean_bneq = false;
		const _visibleCommands_function_BaZB = () => { };
		const _subcommandTerm_function_YqlF = () => { };
		const _subcommandDescription_function_ZvwT = () => { };
		const _helper_object_zriE = {
			"padWidth": _padWidth_function_cSON,
		"helpWidth": _helpWidth_numeric_pVYR,
		"wrap": _wrap_function_cdgS,
		"commandUsage": _commandUsage_function_Hcuh,
		"commandDescription": _commandDescription_function_jUaj,
		"visibleArguments": _visibleArguments_function_QCIH,
		"argumentTerm": _argumentTerm_function_rdLC,
		"argumentDescription": _argumentDescription_function_kbqi,
		"visibleOptions": _visibleOptions_function_eSyn,
		"optionTerm": _optionTerm_function_tLbs,
		"optionDescription": _optionDescription_boolean_bneq,
		"visibleCommands": _visibleCommands_function_BaZB,
		"subcommandTerm": _subcommandTerm_function_YqlF,
		"subcommandDescription": _subcommandDescription_function_ZvwT
	}
		const _formatHelp_function_XLKd = await _Help_object_yZbD.formatHelp(_cmd_null_oJEK, _helper_object_zriE)
		const _map_function_wuGt = () => { };
		const _argChoices_object_eyZD = {
			"map": _map_function_wuGt
	}
		const _negate_string_OORh = "a077AP7kX3gRpgqIR5elw8qcPMqiqJomE1FU2TAEgKqieNopoLPYfMXqQcACOTtzmdJrRklFRO4VTPLlpKG";
		const _defaultValue_object_Xlyc = {
		
	}
		const _defaultValueDescription_boolean_bqQP = false;
		const _envVar_function_ZaxQ = () => { };
		const _description_object_AAqc = {
		
	}
		const _option_object_ZMzD = {
			"argChoices": _argChoices_object_eyZD,
		"negate": _negate_string_OORh,
		"defaultValue": _defaultValue_object_Xlyc,
		"defaultValueDescription": _defaultValueDescription_boolean_bqQP,
		"envVar": _envVar_function_ZaxQ,
		"description": _description_object_AAqc
	}
		const _optionDescription_function_UPiA = await _Help_object_yZbD.optionDescription(_option_object_ZMzD)
		const _cmd_string_EQzu = "IeR6lIvSDI17QAMa5AQ33SW9ddTJ6SEgipOT9Hrix22bx2jRCh9MI7jygf7uCvK4xoxRqiPltpoFQ";
		const _helper_function_CsIw = () => { };
		const _longestArgumentTermLength_function_QwYr = await _Help_object_yZbD.longestArgumentTermLength(_cmd_string_EQzu, _helper_function_CsIw)
		const __argsDescription_boolean_HOPR = false;
		const __args_object_zjXR = {
		
	}
		const _cmd_object_bpnO = {
			"_argsDescription": __argsDescription_boolean_HOPR,
		"_args": __args_object_zjXR
	}
		const _visibleArguments_function_dqvo = await _Help_object_yZbD.visibleArguments(_cmd_object_bpnO)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:29:48:::29:67:::948:967
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:212:2:::215:3:::6121:6239
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:236:2:::256:3:::6636:7432
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:240:4:::244:5:::6796:7026
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:245:4:::247:5:::7031:7202
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:249:6:::249:46:::7248:7288
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:252:6:::252:63:::7333:7390
		const _Help_object_wMVS = new Help()
		const _anon_string_nKbR = "QHAIbgTEvNwusI9MMVFBOXXb5b5UGhEbMo4EOKDkduRHA2cqUlbfDrRso1Kj3zP4am9jWy1AL3b3Cs6p41FvjS6s2";
		const _argChoices_array_tnYe = [_anon_string_nKbR]
		const _negate_string_KKNl = "xsGuO0ACBWUGGR6t1qTkQ";
		const _defaultValue_boolean_aXuI = true;
		const _defaultValueDescription_boolean_uPWd = false;
		const _envVar_numeric_uHRt = 1.593544879210837;
		const _anon_string_vVyE = "4nt4jbSpKcLW1JumG6gGGplFJWGyfKNmspIwe2G8wLvPfxYOhmAchy1T6BPo4H6xlDYpdNSTnQKO3IAX3JzB";
		const _description_array_TpBn = [_anon_string_vVyE]
		const _option_object_YThA = {
			"argChoices": _argChoices_array_tnYe,
		"negate": _negate_string_KKNl,
		"defaultValue": _defaultValue_boolean_aXuI,
		"defaultValueDescription": _defaultValueDescription_boolean_uPWd,
		"envVar": _envVar_numeric_uHRt,
		"description": _description_array_TpBn
	}
		const _optionDescription_function_KIgK = await _Help_object_wMVS.optionDescription(_option_object_YThA)
		const _description_function_xuPL = () => { };
		const _cmd_object_khkz = {
			"description": _description_function_xuPL
	}
		const _commandDescription_function_BdFF = await _Help_object_wMVS.commandDescription(_cmd_object_khkz)
		const _anon_string_ooHG = "3rEzJApINbqArUhdEJ5mMBjh1gYGk8hq9Bad2p8Wvo8r39ubtc2NMhO6C31dEnfpEvz";
		const _commands_array_ERZp = [_anon_string_ooHG]
		const __hasImplicitHelpCommand_string_jqyP = "ediAbe6wMifskpnR8IlfucfrrcD3i2Y0XpEQBRpTTgYgCuU";
		const _match_function_iKOp = () => { };
		const __helpCommandnameAndArgs_object_GnSg = {
			"match": _match_function_iKOp
	}
		const _createCommand_numeric_JPnU = 2.8386190165672094;
		const __helpCommandDescription_null_wual = null;
		const _cmd_object_ajwa = {
			"commands": _commands_array_ERZp,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_string_jqyP,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_object_GnSg,
		"createCommand": _createCommand_numeric_JPnU,
		"_helpCommandDescription": __helpCommandDescription_null_wual
	}
		const _visibleCommands_function_JDku = await _Help_object_wMVS.visibleCommands(_cmd_object_ajwa)
		const _cmd_boolean_xZet = false;
		const _padWidth_function_WOKl = () => { };
		const _helpWidth_boolean_Eats = true;
		const _wrap_function_yUsL = () => { };
		const _commandUsage_function_wWTe = () => { };
		const _commandDescription_function_jjPq = () => { };
		const _visibleArguments_function_LNCD = () => { };
		const _argumentTerm_function_RoLJ = () => { };
		const _argumentDescription_function_lmMi = () => { };
		const _visibleOptions_boolean_qeiu = false;
		const _optionTerm_function_gACO = () => { };
		const _optionDescription_function_Rjjw = () => { };
		const _visibleCommands_undefined_ABxv = undefined;
		const _subcommandTerm_string_UQsv = "7DSYbQEhfCVYbcpFVrMERa6E6frlaf7pu";
		const _subcommandDescription_function_uJND = () => { };
		const _helper_object_AUyO = {
			"padWidth": _padWidth_function_WOKl,
		"helpWidth": _helpWidth_boolean_Eats,
		"wrap": _wrap_function_yUsL,
		"commandUsage": _commandUsage_function_wWTe,
		"commandDescription": _commandDescription_function_jjPq,
		"visibleArguments": _visibleArguments_function_LNCD,
		"argumentTerm": _argumentTerm_function_RoLJ,
		"argumentDescription": _argumentDescription_function_lmMi,
		"visibleOptions": _visibleOptions_boolean_qeiu,
		"optionTerm": _optionTerm_function_gACO,
		"optionDescription": _optionDescription_function_Rjjw,
		"visibleCommands": _visibleCommands_undefined_ABxv,
		"subcommandTerm": _subcommandTerm_string_UQsv,
		"subcommandDescription": _subcommandDescription_function_uJND
	}
		const _formatHelp_function_PwsA = await _Help_object_wMVS.formatHelp(_cmd_boolean_xZet, _helper_object_AUyO)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:128:2:::130:3:::4257:4306
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:224:2:::227:3:::6379:6500
		const _Help_object_rMeg = new Help()
		const _description_function_VPHp = () => { };
		const _cmd_object_gNLB = {
			"description": _description_function_VPHp
	}
		const _subcommandDescription_function_CjNy = await _Help_object_rMeg.subcommandDescription(_cmd_object_gNLB)
		const _flags_object_MgNV = {
		
	}
		const _option_object_uwMg = {
			"flags": _flags_object_MgNV
	}
		const _optionTerm_function_zYGt = await _Help_object_rMeg.optionTerm(_option_object_uwMg)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:165:2:::169:3:::4968:5147
		const _Help_object_qjfq = new Help()
		const _anon_string_Sawf = "hdQG4XoBuNOJUi";
		const _argChoices_array_WyyH = [_anon_string_Sawf]
		const _negate_function_hfkS = () => { };
		const _defaultValue_undefined_SsPL = undefined;
		const _defaultValueDescription_function_sLZa = () => { };
		const _envVar_null_pKfa = null;
		const _description_function_wrqJ = () => { };
		const _option_object_XTDL = {
			"argChoices": _argChoices_array_WyyH,
		"negate": _negate_function_hfkS,
		"defaultValue": _defaultValue_undefined_SsPL,
		"defaultValueDescription": _defaultValueDescription_function_sLZa,
		"envVar": _envVar_null_pKfa,
		"description": _description_function_wrqJ
	}
		const _optionDescription_function_rRub = await _Help_object_qjfq.optionDescription(_option_object_XTDL)
		const _cmd_function_FZyx = () => { };
		const _visibleOptions_function_UJvZ = () => { };
		const _optionTerm_function_vlby = () => { };
		const _helper_object_tjZD = {
			"visibleOptions": _visibleOptions_function_UJvZ,
		"optionTerm": _optionTerm_function_vlby
	}
		const _longestOptionTermLength_function_vhkI = await _Help_object_qjfq.longestOptionTermLength(_cmd_function_FZyx, _helper_object_tjZD)
		const _map_function_Zrph = () => { };
		const _argChoices_object_KxLv = {
			"map": _map_function_Zrph
	}
		const _negate_null_tjus = null;
		const _defaultValue_null_vOJh = null;
		const _defaultValueDescription_boolean_ffOu = true;
		const _anon_string_oQsa = "kl1fff9vaRdbGmAaB8EWxKhvBuCFjpmXvCoPkg4IRAkeqA1mrCmtq88jWU3SXHoXAaxgR";
		const _envVar_array_DsDD = [_anon_string_oQsa]
		const _description_boolean_zVEo = false;
		const _option_object_tVhY = {
			"argChoices": _argChoices_object_KxLv,
		"negate": _negate_null_tjus,
		"defaultValue": _defaultValue_null_vOJh,
		"defaultValueDescription": _defaultValueDescription_boolean_ffOu,
		"envVar": _envVar_array_DsDD,
		"description": _description_boolean_zVEo
	}
		const _optionDescription_function_kWqa = await _Help_object_qjfq.optionDescription(_option_object_tVhY)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:265:2:::283:3:::7577:8286
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:268:6:::270:94:::7672:7849
		const _Help_object_EVWm = new Help()
		const _map_function_RVsq = () => { };
		const _argChoices_object_HNjU = {
			"map": _map_function_RVsq
	}
		const _defaultValue_undefined_AGgN = undefined;
		const _defaultValueDescription_boolean_epdb = true;
		const _description_string_LosG = "nO0oFF1BKowCuUXHcmX9ISz5iaHaQxQdA5ifdzOQWutGKn7xCxvtlIE3X6j1uVFRlt9xf75UoirU0CI";
		const _argument_object_ghmY = {
			"argChoices": _argChoices_object_HNjU,
		"defaultValue": _defaultValue_undefined_AGgN,
		"defaultValueDescription": _defaultValueDescription_boolean_epdb,
		"description": _description_string_LosG
	}
		const _argumentDescription_function_QtrO = await _Help_object_EVWm.argumentDescription(_argument_object_ghmY)
		const _anon_string_XfSd = "oCQqPB8j";
		const _cmd_array_IDkQ = [_anon_string_XfSd]
		const _visibleOptions_function_aEzB = () => { };
		const _optionTerm_null_bNht = null;
		const _helper_object_Avqy = {
			"visibleOptions": _visibleOptions_function_aEzB,
		"optionTerm": _optionTerm_null_bNht
	}
		const _longestOptionTermLength_function_ZOLL = await _Help_object_EVWm.longestOptionTermLength(_cmd_array_IDkQ, _helper_object_Avqy)
		const _cmd_string_ZGoa = "1BCj16HmPK9brQZ5CsQMrMDxWK1LTDQohawJBLK24ReOok40jTPV2MFEu2bLMoPe1uz3Plr7VjAEpmTe0TCzSUridmMMVkfQ";
		const _longestOptionTermLength_function_NSzr = () => { };
		const _longestSubcommandTermLength_function_fFUx = () => { };
		const _longestArgumentTermLength_function_sFtD = () => { };
		const _helper_object_XGbh = {
			"longestOptionTermLength": _longestOptionTermLength_function_NSzr,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_fFUx,
		"longestArgumentTermLength": _longestArgumentTermLength_function_sFtD
	}
		const _padWidth_function_NeQu = await _Help_object_EVWm.padWidth(_cmd_string_ZGoa, _helper_object_XGbh)
		const _cmd_undefined_QcDf = undefined;
		const _padWidth_function_EEKv = () => { };
		const _helpWidth_numeric_yjAb = -9.676567208373722;
		const _wrap_function_CeUP = () => { };
		const _commandUsage_function_CVzA = () => { };
		const _commandDescription_function_fGCp = () => { };
		const _visibleArguments_function_prDg = () => { };
		const _argumentTerm_function_sMru = () => { };
		const _argumentDescription_function_wvCt = () => { };
		const _visibleOptions_function_bOJr = () => { };
		const _optionTerm_function_VvGj = () => { };
		const _optionDescription_function_wGnT = () => { };
		const _visibleCommands_function_Qpow = () => { };
		const _subcommandTerm_function_PPHh = () => { };
		const _subcommandDescription_function_dqOr = () => { };
		const _helper_object_yqrK = {
			"padWidth": _padWidth_function_EEKv,
		"helpWidth": _helpWidth_numeric_yjAb,
		"wrap": _wrap_function_CeUP,
		"commandUsage": _commandUsage_function_CVzA,
		"commandDescription": _commandDescription_function_fGCp,
		"visibleArguments": _visibleArguments_function_prDg,
		"argumentTerm": _argumentTerm_function_sMru,
		"argumentDescription": _argumentDescription_function_wvCt,
		"visibleOptions": _visibleOptions_function_bOJr,
		"optionTerm": _optionTerm_function_VvGj,
		"optionDescription": _optionDescription_function_wGnT,
		"visibleCommands": _visibleCommands_function_Qpow,
		"subcommandTerm": _subcommandTerm_function_PPHh,
		"subcommandDescription": _subcommandDescription_function_dqOr
	}
		const _formatHelp_function_ZNZN = await _Help_object_EVWm.formatHelp(_cmd_undefined_QcDf, _helper_object_yqrK)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:90:2:::103:3:::3139:3629
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:270:44:::270:78:::7799:7833
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:273:6:::273:110:::7909:8013
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:93:6:::95:9:::3287:3428
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:92:4:::96:5:::3253:3434
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:276:6:::276:58:::8058:8110
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:277:6:::279:7:::8117:8213
		const _Help_object_vdSt = new Help()
		const _anon_string_Wftb = "11YtFlpk7ME4akwCkMSR9YCU7GZ2QAeudBhlhAH2aLetyJGOS58Onj8J7nlHLd1GTEoCYwmCRZyNy0k";
		const _argChoices_array_VUOf = [_anon_string_Wftb]
		const _defaultValue_numeric_pAZI = 0.1549046421483684;
		const _defaultValueDescription_null_PFYy = null;
		const _description_null_YWsC = null;
		const _argument_object_qSBc = {
			"argChoices": _argChoices_array_VUOf,
		"defaultValue": _defaultValue_numeric_pAZI,
		"defaultValueDescription": _defaultValueDescription_null_PFYy,
		"description": _description_null_YWsC
	}
		const _argumentDescription_function_EHjc = await _Help_object_vdSt.argumentDescription(_argument_object_qSBc)
		const __argsDescription_numeric_ssSl = 3.0084676016481637;
		const __args_function_sjhS = () => { };
		const _cmd_object_pxYO = {
			"_argsDescription": __argsDescription_numeric_ssSl,
		"_args": __args_function_sjhS
	}
		const _visibleArguments_function_BbVk = await _Help_object_vdSt.visibleArguments(_cmd_object_pxYO)
		const _cmd_function_XBWS = () => { };
		const _visibleOptions_numeric_YgTG = -9.016455205245057;
		const _optionTerm_null_aEJf = null;
		const _helper_object_CBrC = {
			"visibleOptions": _visibleOptions_numeric_YgTG,
		"optionTerm": _optionTerm_null_aEJf
	}
		const _longestOptionTermLength_function_OKfE = await _Help_object_vdSt.longestOptionTermLength(_cmd_function_XBWS, _helper_object_CBrC)
		const _flags_boolean_jYyQ = true;
		const _option_object_pGQr = {
			"flags": _flags_boolean_jYyQ
	}
		const _optionTerm_function_aGxi = await _Help_object_vdSt.optionTerm(_option_object_pGQr)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:151:2:::155:3:::4639:4829
		const _Help_object_oaZe = new Help()
		const _cmd_function_yVmV = () => { };
		const _visibleCommands_string_BGmj = "WbpHRj1nXmcmOulyomKMH9Ptlifj7jNGbPEIRklIdgIlt8sU6E7lqtx7ApTW1GHWq8pxrTkezmP93ikTTlCVUdqrtx6mb";
		const _subcommandTerm_function_Movt = () => { };
		const _helper_object_xuGT = {
			"visibleCommands": _visibleCommands_string_BGmj,
		"subcommandTerm": _subcommandTerm_function_Movt
	}
		const _longestSubcommandTermLength_function_VchQ = await _Help_object_oaZe.longestSubcommandTermLength(_cmd_function_yVmV, _helper_object_xuGT)
		const _description_function_Ojvu = () => { };
		const _cmd_object_XCEO = {
			"description": _description_function_Ojvu
	}
		const _subcommandDescription_function_QLTM = await _Help_object_oaZe.subcommandDescription(_cmd_object_XCEO)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:55:2:::81:3:::1819:3002
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:56:46:::56:72:::1887:1913
		const _Help_object_RWOQ = new Help()
		const _anon_string_ccIK = "4nt4jbSpKcLW1JumG6gGGplFJWGyfKNmspIwe2G8wLvPfxYOhmAchy1T6BPo4H6xlDYpdNSTnQKO3IAX3JzB";
		const _options_array_ikfw = [_anon_string_ccIK]
		const __hasHelpOption_boolean_JELV = true;
		const __helpShortFlag_null_dsDc = null;
		const __findOption_string_suRP = "pEeXtBUOof4PXkjWW73kLK9vXNiQJHB3MLO3t53VvthRPEWW2Cx6LqYw6fL";
		const __helpLongFlag_string_JPKF = "hwViwzlpArY16ruzMH7q1v0s9nxp";
		const _createOption_function_roLq = () => { };
		const __helpDescription_object_WmNJ = {
		
	}
		const _anon_string_KZXf = "4nL2eHYIFH9tmrVggigWyadV58Hc2P";
		const __helpFlags_array_cWZg = [_anon_string_KZXf]
		const _cmd_object_VRzx = {
			"options": _options_array_ikfw,
		"_hasHelpOption": __hasHelpOption_boolean_JELV,
		"_helpShortFlag": __helpShortFlag_null_dsDc,
		"_findOption": __findOption_string_suRP,
		"_helpLongFlag": __helpLongFlag_string_JPKF,
		"createOption": _createOption_function_roLq,
		"_helpDescription": __helpDescription_object_WmNJ,
		"_helpFlags": __helpFlags_array_cWZg
	}
		const _visibleOptions_function_XtrN = await _Help_object_RWOQ.visibleOptions(_cmd_object_VRzx)
		const _filter_function_NoTt = () => { };
		const _options_object_hdpc = {
			"filter": _filter_function_NoTt
	}
		const __hasHelpOption_boolean_UXPT = true;
		const __helpShortFlag_null_dxgY = null;
		const _anon_string_TsvH = "hpfqe35xDYTSCBVhArojtEjEmt2YkQBBF9pskOslKL9E6yhXe3f6bm2ACUymE87j7hFPncIg8";
		const __findOption_array_LbUO = [_anon_string_TsvH]
		const __helpLongFlag_numeric_LAeM = 9.370791055703847;
		const _createOption_function_bQaD = () => { };
		const __helpDescription_string_lkQh = "SHmrWbi04gqUCDQjdygOsleOzYmaYnE6Hmy68yWlCpy4BW3vrBLiQC7RVTKgkdFqBa9duYbH14JHfHKhdNGwoDBaiabCVz";
		const __helpFlags_function_qFqf = () => { };
		const _cmd_object_cDEz = {
			"options": _options_object_hdpc,
		"_hasHelpOption": __hasHelpOption_boolean_UXPT,
		"_helpShortFlag": __helpShortFlag_null_dxgY,
		"_findOption": __findOption_array_LbUO,
		"_helpLongFlag": __helpLongFlag_numeric_LAeM,
		"createOption": _createOption_function_bQaD,
		"_helpDescription": __helpDescription_string_lkQh,
		"_helpFlags": __helpFlags_function_qFqf
	}
		const _visibleOptions_function_rZln = await _Help_object_RWOQ.visibleOptions(_cmd_object_cDEz)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:192:2:::203:3:::5625:6008
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:196:6:::196:48:::5720:5762
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:199:4:::201:5:::5802:5947
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:200:6:::200:63:::5884:5941
		const _Help_object_ZDXA = new Help()
		const _flags_boolean_bsFF = true;
		const _option_object_ZNaX = {
			"flags": _flags_boolean_bsFF
	}
		const _optionTerm_function_wQgQ = await _Help_object_ZDXA.optionTerm(_option_object_ZNaX)
		const __name_numeric_HZMg = 6.27456145621672;
		const _anon_string_AqSs = "I9S3I3thsMAzhFI5VKTMMO6kpBFQV";
		const __aliases_array_iiut = [_anon_string_AqSs]
		const _parent_function_kNoh = () => { };
		const _name_function_gIcc = () => { };
		const _parent_object_INdv = {
			"parent": _parent_function_kNoh,
		"name": _name_function_gIcc
	}
		const _usage_function_wSay = () => { };
		const _cmd_object_nUNQ = {
			"_name": __name_numeric_HZMg,
		"_aliases": __aliases_array_iiut,
		"parent": _parent_object_INdv,
		"usage": _usage_function_wSay
	}
		const _commandUsage_function_Cxfk = await _Help_object_ZDXA.commandUsage(_cmd_object_nUNQ)
		const _argChoices_string_yhKo = "ic2iRRyX3WfcVqGWKv878vbYR6H5dAKsISf";
		const _negate_string_cnaN = "c6AD4O5wZJg7SO1prfiBR9pMTZWP36jo4LMbmpzsRufPhAQ7tYo54G722bAGELOszrjK6cnGautRnfRkqct";
		const _defaultValue_object_vACg = {
		
	}
		const _defaultValueDescription_string_kJbu = "3MOyv8xAHRlDWxQXxUPLvzaQGN7ddILoWSrLpuBSp2l1tPNgScGRbIEvEfWiuClEG7iGuFH";
		const _envVar_boolean_fMaU = true;
		const _description_null_cxSO = null;
		const _option_object_Sxpk = {
			"argChoices": _argChoices_string_yhKo,
		"negate": _negate_string_cnaN,
		"defaultValue": _defaultValue_object_vACg,
		"defaultValueDescription": _defaultValueDescription_string_kJbu,
		"envVar": _envVar_boolean_fMaU,
		"description": _description_null_cxSO
	}
		const _optionDescription_function_ZYrf = await _Help_object_ZDXA.optionDescription(_option_object_Sxpk)
		const _match_function_ntIm = () => { };
		const _substr_object_cDPi = {
		
	}
		const _str_object_lbse = {
			"match": _match_function_ntIm,
		"substr": _substr_object_cDPi
	}
		const _width_numeric_ENbQ = -4.591789981621897;
		const _indent_numeric_Fypu = -7.967210937153923;
		const _Assignment_numeric_Ucne = 0.3375231212703156;
		const _wrap_function_yoyK = await _Help_object_ZDXA.wrap(_str_object_lbse, _width_numeric_ENbQ, _indent_numeric_Fypu, _Assignment_numeric_Ucne)
		const _argChoices_object_xLOM = {
		
	}
		const _defaultValue_null_ygya = null;
		const _defaultValueDescription_boolean_lPSJ = true;
		const _description_null_ZBsm = null;
		const _argument_object_zPMt = {
			"argChoices": _argChoices_object_xLOM,
		"defaultValue": _defaultValue_null_ygya,
		"defaultValueDescription": _defaultValueDescription_boolean_lPSJ,
		"description": _description_null_ZBsm
	}
		const _argumentDescription_function_UAEa = await _Help_object_ZDXA.argumentDescription(_argument_object_zPMt)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:112:2:::119:3:::3762:4127
		const _Help_object_BOZy = new Help()
		const _map_string_zfzz = "WC89xMZiO6r5madYDeynFq";
		const __args_object_VXgk = {
			"map": _map_string_zfzz
	}
		const __name_string_VLVS = "KzR4onXw9Gpz1kTIf6P84oTe2sn4J772r9nuIkzS4hm6Sir36CsdZacEdXsQk99ejK7BjiITfUky";
		const _anon_string_HoJT = "2blTPvJLjH5PvOf4JVt0VLQhjUssSzLs";
		const __aliases_array_QHPr = [_anon_string_HoJT]
		const _options_function_hvTN = () => { };
		const _cmd_object_NGuV = {
			"_args": __args_object_VXgk,
		"_name": __name_string_VLVS,
		"_aliases": __aliases_array_QHPr,
		"options": _options_function_hvTN
	}
		const _subcommandTerm_function_nrkY = await _Help_object_BOZy.subcommandTerm(_cmd_object_NGuV)
		const _cmd_function_vwav = () => { };
		const _longestOptionTermLength_function_PDpQ = () => { };
		const _longestSubcommandTermLength_function_XixA = () => { };
		const _longestArgumentTermLength_function_Aave = () => { };
		const _helper_object_rjRW = {
			"longestOptionTermLength": _longestOptionTermLength_function_PDpQ,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_XixA,
		"longestArgumentTermLength": _longestArgumentTermLength_function_Aave
	}
		const _padWidth_function_pMVX = await _Help_object_BOZy.padWidth(_cmd_function_vwav, _helper_object_rjRW)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:179:2:::183:3:::5288:5477
		const _Help_object_LddX = new Help()
		const _cmd_string_VOrL = "KUDxLKbaKxpigPzY1SdcpJU8LNW2nKqrfYag7322t";
		const _visibleArguments_function_ZmMD = () => { };
		const _argumentTerm_function_QopV = () => { };
		const _helper_object_SusF = {
			"visibleArguments": _visibleArguments_function_ZmMD,
		"argumentTerm": _argumentTerm_function_QopV
	}
		const _longestArgumentTermLength_function_fWkA = await _Help_object_LddX.longestArgumentTermLength(_cmd_string_VOrL, _helper_object_SusF)
		const _cmd_function_RvxI = () => { };
		const _longestOptionTermLength_function_sTKP = () => { };
		const _longestSubcommandTermLength_function_PgjC = () => { };
		const _longestArgumentTermLength_function_NvUu = () => { };
		const _helper_object_SZKT = {
			"longestOptionTermLength": _longestOptionTermLength_function_sTKP,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_PgjC,
		"longestArgumentTermLength": _longestArgumentTermLength_function_NvUu
	}
		const _padWidth_function_iXCt = await _Help_object_LddX.padWidth(_cmd_function_RvxI, _helper_object_SZKT)
		const _anon_string_fVag = "4nt4jbSpKcLW1JumG6gGGplFJWGyfKNmspIwe2G8wLvPfxYOhmAchy1T6BPo4H6xlDYpdNSTnQKO3IAX3JzB";
		const _cmd_array_TXbL = [_anon_string_fVag]
		const _visibleCommands_function_icWJ = () => { };
		const _subcommandTerm_function_JQPh = () => { };
		const _helper_object_nLqo = {
			"visibleCommands": _visibleCommands_function_icWJ,
		"subcommandTerm": _subcommandTerm_function_JQPh
	}
		const _longestSubcommandTermLength_function_xZTp = await _Help_object_LddX.longestSubcommandTermLength(_cmd_array_TXbL, _helper_object_nLqo)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:114:31:::114:63:::3880:3912
		const _Help_object_Qmwt = new Help()
		const _anon_string_Siwg = "Yx7PDJSr9t2VtpscDSH58PAuDTOyztph3w16dQKavmLmr53Hmk6HsO3W3sS88VkB2g";
		const __args_array_DvHo = [_anon_string_Siwg]
		const __name_numeric_VOFu = -9.943776745999228;
		const _anon_string_WZBz = "mUc3qn6YYvD2WVTmArxlxZvpMX9uCYdjMZt5h8yNFskI1dzHUkOHin8F4Lz0MZzi3Dl5";
		const __aliases_array_Pxbx = [_anon_string_WZBz]
		const _options_function_zQyd = () => { };
		const _cmd_object_gXfG = {
			"_args": __args_array_DvHo,
		"_name": __name_numeric_VOFu,
		"_aliases": __aliases_array_Pxbx,
		"options": _options_function_zQyd
	}
		const _subcommandTerm_function_hSlE = await _Help_object_Qmwt.subcommandTerm(_cmd_object_gXfG)
		const _filter_function_HIhM = () => { };
		const _commands_object_KBEF = {
			"filter": _filter_function_HIhM
	}
		const __hasImplicitHelpCommand_function_YSVm = () => { };
		const _match_function_WaGa = () => { };
		const __helpCommandnameAndArgs_object_XpeS = {
			"match": _match_function_WaGa
	}
		const _createCommand_function_zoyr = () => { };
		const __helpCommandDescription_null_KyON = null;
		const _cmd_object_HgFi = {
			"commands": _commands_object_KBEF,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_function_YSVm,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_object_XpeS,
		"createCommand": _createCommand_function_zoyr,
		"_helpCommandDescription": __helpCommandDescription_null_KyON
	}
		const _visibleCommands_function_OvMU = await _Help_object_Qmwt.visibleCommands(_cmd_object_HgFi)
		const _filter_null_cTfE = null;
		const _options_object_YsDT = {
			"filter": _filter_null_cTfE
	}
		const __hasHelpOption_boolean_ieAS = true;
		const __helpShortFlag_undefined_nVQN = undefined;
		const __findOption_function_jUFt = () => { };
		const __helpLongFlag_string_GoMi = "35okm0Bjp5aN6cMBJzlguUg1rwvhbe8R7FOOirnLPVrBeJOndC2Hu2BSo33hPeIhsFEmmRwsqlcxNJS2eliXCb4Wr";
		const _createOption_function_tVRs = () => { };
		const __helpDescription_numeric_EHNl = -6.0411776786613505;
		const __helpFlags_null_JiEO = null;
		const _cmd_object_HeHM = {
			"options": _options_object_YsDT,
		"_hasHelpOption": __hasHelpOption_boolean_ieAS,
		"_helpShortFlag": __helpShortFlag_undefined_nVQN,
		"_findOption": __findOption_function_jUFt,
		"_helpLongFlag": __helpLongFlag_string_GoMi,
		"createOption": _createOption_function_tVRs,
		"_helpDescription": __helpDescription_numeric_EHNl,
		"_helpFlags": __helpFlags_null_JiEO
	}
		const _visibleOptions_function_ehBV = await _Help_object_Qmwt.visibleOptions(_cmd_object_HeHM)


	});

	it('test for help', async () => {

		const _Help_object_gYwm = new Help()
		const __argsDescription_string_UFxj = "f8KcuD";
		const __args_null_BHeD = null;
		const _cmd_object_xkKL = {
			"_argsDescription": __argsDescription_string_UFxj,
		"_args": __args_null_BHeD
	}
		const _visibleArguments_function_JTCd = await _Help_object_gYwm.visibleArguments(_cmd_object_xkKL)
		const _description_function_MQNp = () => { };
		const _cmd_object_YCXo = {
			"description": _description_function_MQNp
	}
		const _subcommandDescription_function_teWM = await _Help_object_gYwm.subcommandDescription(_cmd_object_YCXo)
		const _filter_function_YQnB = () => { };
		const _options_object_QMyp = {
			"filter": _filter_function_YQnB
	}
		const __hasHelpOption_boolean_HspV = false;
		const __helpShortFlag_string_SHsf = "1";
		const __findOption_function_PlBk = () => { };
		const __helpLongFlag_function_QDsB = () => { };
		const _createOption_numeric_LFqe = 7.043390305051052;
		const __helpDescription_string_guqw = "hKaTcLjcd1xKnac9SWZ9srYtbhEz2uxYduKaTXzNqH3rPSX";
		const __helpFlags_function_edVQ = () => { };
		const _cmd_object_JUGV = {
			"options": _options_object_QMyp,
		"_hasHelpOption": __hasHelpOption_boolean_HspV,
		"_helpShortFlag": __helpShortFlag_string_SHsf,
		"_findOption": __findOption_function_PlBk,
		"_helpLongFlag": __helpLongFlag_function_QDsB,
		"createOption": _createOption_numeric_LFqe,
		"_helpDescription": __helpDescription_string_guqw,
		"_helpFlags": __helpFlags_function_edVQ
	}
		const _visibleOptions_function_DRWA = await _Help_object_gYwm.visibleOptions(_cmd_object_JUGV)
		const _cmd_string_WzKU = "U8yVRacGfXBTwJ7mUOYUuPlBDrnlpQ3EVCb8DJcSBUPCNUSikUwgqdhSaJdjnkLflWkEIK2TRxtLbXUkinL69mVJ55cO";
		const _visibleArguments_function_eufr = () => { };
		const _argumentTerm_function_kfse = () => { };
		const _helper_object_uGzS = {
			"visibleArguments": _visibleArguments_function_eufr,
		"argumentTerm": _argumentTerm_function_kfse
	}
		const _longestArgumentTermLength_function_hmjB = await _Help_object_gYwm.longestArgumentTermLength(_cmd_string_WzKU, _helper_object_uGzS)


	});

	it('test for help', async () => {
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:30:4:::38:5:::974:1403
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:39:4:::44:5:::1408:1602
		const _Help_object_ebOX = new Help()
		const _filter_function_iZKz = () => { };
		const _commands_object_bkTN = {
			"filter": _filter_function_iZKz
	}
		const __hasImplicitHelpCommand_function_NHZZ = () => { };
		const __helpCommandnameAndArgs_string_Cpxx = "ulbSPjKgB9mqG3MEKaWa3a3bPSyTRSfdqryIiXx3dVKDKYfl4AuNirznc5rLx7rDkoxwGPyVirig58JPkMa";
		const _createCommand_function_JpTb = () => { };
		const __helpCommandDescription_boolean_tkRa = true;
		const _cmd_object_yOUI = {
			"commands": _commands_object_bkTN,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_function_NHZZ,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_string_Cpxx,
		"createCommand": _createCommand_function_JpTb,
		"_helpCommandDescription": __helpCommandDescription_boolean_tkRa
	}
		const _visibleCommands_function_Ykrv = await _Help_object_ebOX.visibleCommands(_cmd_object_yOUI)
		const _cmd_string_MYjN = "cHBRJUrNeuRcplJ";
		const _visibleArguments_function_kDWW = () => { };
		const _argumentTerm_function_XBsg = () => { };
		const _helper_object_OVyP = {
			"visibleArguments": _visibleArguments_function_kDWW,
		"argumentTerm": _argumentTerm_function_XBsg
	}
		const _longestArgumentTermLength_function_TGQN = await _Help_object_ebOX.longestArgumentTermLength(_cmd_string_MYjN, _helper_object_OVyP)
		const _map_object_HXts = {
		
	}
		const _argChoices_object_QYuj = {
			"map": _map_object_HXts
	}
		const _negate_string_aHsK = "jZ01rP6ldOI45stEk8NAIgrO8ViElPvxdxaZe5AzVbPXbsbvXiggbdPJni6Soi2iK";
		const _defaultValue_object_Fhqc = {
		
	}
		const _defaultValueDescription_boolean_pNqC = false;
		const _envVar_numeric_nxqq = -8.218682987692391;
		const _description_null_rMrr = null;
		const _option_object_LGIt = {
			"argChoices": _argChoices_object_QYuj,
		"negate": _negate_string_aHsK,
		"defaultValue": _defaultValue_object_Fhqc,
		"defaultValueDescription": _defaultValueDescription_boolean_pNqC,
		"envVar": _envVar_numeric_nxqq,
		"description": _description_null_rMrr
	}
		const _optionDescription_function_vSea = await _Help_object_ebOX.optionDescription(_option_object_LGIt)
		const _filter_function_YsqR = () => { };
		const _commands_object_RQKN = {
			"filter": _filter_function_YsqR
	}
		const __hasImplicitHelpCommand_function_fBsf = () => { };
		const _match_function_uYqL = () => { };
		const __helpCommandnameAndArgs_object_AqfW = {
			"match": _match_function_uYqL
	}
		const _createCommand_function_enOI = () => { };
		const __helpCommandDescription_numeric_gJaY = 3.500463862207514;
		const _cmd_object_mjfl = {
			"commands": _commands_object_RQKN,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_function_fBsf,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_object_AqfW,
		"createCommand": _createCommand_function_enOI,
		"_helpCommandDescription": __helpCommandDescription_numeric_gJaY
	}
		const _visibleCommands_function_TfRQ = await _Help_object_ebOX.visibleCommands(_cmd_object_mjfl)
		const __name_numeric_YhCp = 1.7081079745818997;
		const _anon_string_SgCI = "4nt4jbSpKcLW1JumG6gGGplFJWGyfKNmspIwe2G8wLvPfxYOhmAchy1T6BPo4H6xlDYpdNSTnQKO3IAX3JzB";
		const __aliases_array_kipF = [_anon_string_SgCI]
		const _parent_function_gjlQ = () => { };
		const _usage_function_rJNK = () => { };
		const _cmd_object_iyad = {
			"_name": __name_numeric_YhCp,
		"_aliases": __aliases_array_kipF,
		"parent": _parent_function_gjlQ,
		"usage": _usage_function_rJNK
	}
		const _commandUsage_function_GDov = await _Help_object_ebOX.commandUsage(_cmd_object_iyad)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:278:8:::278:60:::8153:8205
		const _Help_object_WDpc = new Help()
		const _anon_string_JKfl = "hpfqe35xDYTSCBVhArojtEjEmt2YkQBBF9pskOslKL9E6yhXe3f6bm2ACUymE87j7hFPncIg8";
		const _argChoices_array_qPYx = [_anon_string_JKfl]
		const _defaultValue_null_Pkau = null;
		const _anon_string_IrUX = "4nt4jbSpKcLW1JumG6gGGplFJWGyfKNmspIwe2G8wLvPfxYOhmAchy1T6BPo4H6xlDYpdNSTnQKO3IAX3JzB";
		const _defaultValueDescription_array_fKil = [_anon_string_IrUX]
		const _description_string_XPas = "x2rmh0VKcTbsFdsfdrx68tLmv9Wp1MOlHheCYlR7A5grDSelABL7yP5duIPHSkjFj1TFsk434k";
		const _argument_object_PUEx = {
			"argChoices": _argChoices_array_qPYx,
		"defaultValue": _defaultValue_null_Pkau,
		"defaultValueDescription": _defaultValueDescription_array_fKil,
		"description": _description_string_XPas
	}
		const _argumentDescription_function_pwET = await _Help_object_WDpc.argumentDescription(_argument_object_PUEx)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:353:2:::359:3:::10401:10614
		const _Help_object_zlMm = new Help()
		const _description_function_IpZY = () => { };
		const _cmd_object_SCTf = {
			"description": _description_function_IpZY
	}
		const _subcommandDescription_function_wwDG = await _Help_object_zlMm.subcommandDescription(_cmd_object_SCTf)
		const _cmd_string_SGvc = "jhqmCTD3hQmwYalWTwb2vEIDfq69m9oW2lVoHB8yIT1pPUwwczObAqWa7CFkjbpWYnrBQ3f17H";
		const _helper_null_vlnh = null;
		const _padWidth_function_UZll = await _Help_object_zlMm.padWidth(_cmd_string_SGvc, _helper_null_vlnh)
		const _filter_boolean_UvOA = true;
		const _options_object_qMqs = {
			"filter": _filter_boolean_UvOA
	}
		const __hasHelpOption_boolean_OwxM = true;
		const __helpShortFlag_function_coUQ = () => { };
		const __findOption_function_SRlq = () => { };
		const __helpLongFlag_object_Tqbq = {
		
	}
		const _createOption_function_nnOo = () => { };
		const __helpDescription_object_fhbC = {
		
	}
		const __helpFlags_null_xQpu = null;
		const _cmd_object_Emfu = {
			"options": _options_object_qMqs,
		"_hasHelpOption": __hasHelpOption_boolean_OwxM,
		"_helpShortFlag": __helpShortFlag_function_coUQ,
		"_findOption": __findOption_function_SRlq,
		"_helpLongFlag": __helpLongFlag_object_Tqbq,
		"createOption": _createOption_function_nnOo,
		"_helpDescription": __helpDescription_object_fhbC,
		"_helpFlags": __helpFlags_null_xQpu
	}
		const _visibleOptions_function_KOzU = await _Help_object_zlMm.visibleOptions(_cmd_object_Emfu)
		const _anon_string_dJXd = "4nt4jbSpKcLW1JumG6gGGplFJWGyfKNmspIwe2G8wLvPfxYOhmAchy1T6BPo4H6xlDYpdNSTnQKO3IAX3JzB";
		const _options_array_SyfZ = [_anon_string_dJXd]
		const __hasHelpOption_boolean_smqF = false;
		const __helpShortFlag_undefined_GgaD = undefined;
		const __findOption_function_RxcW = () => { };
		const __helpLongFlag_function_XehT = () => { };
		const _createOption_function_hDpB = () => { };
		const __helpDescription_null_UauF = null;
		const __helpFlags_function_abTD = () => { };
		const _cmd_object_HYgz = {
			"options": _options_array_SyfZ,
		"_hasHelpOption": __hasHelpOption_boolean_smqF,
		"_helpShortFlag": __helpShortFlag_undefined_GgaD,
		"_findOption": __findOption_function_RxcW,
		"_helpLongFlag": __helpLongFlag_function_XehT,
		"createOption": _createOption_function_hDpB,
		"_helpDescription": __helpDescription_null_UauF,
		"_helpFlags": __helpFlags_function_abTD
	}
		const _visibleOptions_function_KCRB = await _Help_object_zlMm.visibleOptions(_cmd_object_HYgz)
		const _cmd_boolean_igxd = false;
		const _visibleOptions_function_hZtY = () => { };
		const _optionTerm_function_fupY = () => { };
		const _helper_object_cmeh = {
			"visibleOptions": _visibleOptions_function_hZtY,
		"optionTerm": _optionTerm_function_fupY
	}
		const _longestOptionTermLength_function_fGIg = await _Help_object_zlMm.longestOptionTermLength(_cmd_boolean_igxd, _helper_object_cmeh)


	});

	it('test for help', async () => {

		const _Help_object_zsUC = new Help()
		const _cmd_null_VeQT = null;
		const _longestOptionTermLength_string_bqGA = "I5YxQl9CFzNClxL5Z8Sb8o0FMTcNaEg05khdNFrVX499syD8QuEfNC";
		const _longestSubcommandTermLength_function_PXSL = () => { };
		const _longestArgumentTermLength_function_FJps = () => { };
		const _helper_object_gMdD = {
			"longestOptionTermLength": _longestOptionTermLength_string_bqGA,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_PXSL,
		"longestArgumentTermLength": _longestArgumentTermLength_function_FJps
	}
		const _padWidth_function_ZWjt = await _Help_object_zsUC.padWidth(_cmd_null_VeQT, _helper_object_gMdD)
		const _cmd_string_OURp = "uuvW0QgswWKIBYU14Z3KkYTeaMEJcs8Dkh7qdp9ecZwQErCwHAuVbgfsVAzoYD2QVBVvDAV1zZRMcAlhfZo5GdSG3P3yzH0xt2";
		const _visibleOptions_function_ttTo = () => { };
		const _optionTerm_function_CvYb = () => { };
		const _helper_object_qRfE = {
			"visibleOptions": _visibleOptions_function_ttTo,
		"optionTerm": _optionTerm_function_CvYb
	}
		const _longestOptionTermLength_function_rlfG = await _Help_object_zsUC.longestOptionTermLength(_cmd_string_OURp, _helper_object_qRfE)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:373:2:::393:3:::10981:11915
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:376:4:::376:41:::11155:11192
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:379:4:::379:49:::11344:11389
		const _Help_object_kaMY = new Help()
		const _anon_string_qYMZ = "hpfqe35xDYTSCBVhArojtEjEmt2YkQBBF9pskOslKL9E6yhXe3f6bm2ACUymE87j7hFPncIg8";
		const _argChoices_array_QvOT = [_anon_string_qYMZ]
		const _negate_string_nXhu = "m9PRXxPGXsvfSv8bYDvJeVRKMTku8OQOIQ3tBVW1e9N5XVTQu7BQEoE7RbV5X5Vt7jMmtGJO5aYUaYbR";
		const _defaultValue_string_oCSD = "IRTcRkN6Cxcg9j73OBLAkBbBkpDHF2SnYP5";
		const _defaultValueDescription_boolean_EgAH = true;
		const _anon_string_cEBX = "nkf0QhANXKB1jk1nLORBj6iMx";
		const _envVar_array_BIhW = [_anon_string_cEBX]
		const _description_function_JMSY = () => { };
		const _option_object_Odfd = {
			"argChoices": _argChoices_array_QvOT,
		"negate": _negate_string_nXhu,
		"defaultValue": _defaultValue_string_oCSD,
		"defaultValueDescription": _defaultValueDescription_boolean_EgAH,
		"envVar": _envVar_array_BIhW,
		"description": _description_function_JMSY
	}
		const _optionDescription_function_iduT = await _Help_object_kaMY.optionDescription(_option_object_Odfd)
		const _match_function_Wgqh = () => { };
		const _substr_function_TFlh = () => { };
		const _str_object_Pghs = {
			"match": _match_function_Wgqh,
		"substr": _substr_function_TFlh
	}
		const _width_boolean_CDOG = true;
		const _indent_numeric_uojG = -5.423327420730043;
		const _Assignment_numeric_ajRJ = -1.385683616485558;
		const _wrap_function_JOlp = await _Help_object_kaMY.wrap(_str_object_Pghs, _width_boolean_CDOG, _indent_numeric_uojG, _Assignment_numeric_ajRJ)


	});

	it('test for help', async () => {

		const _Help_object_MLOl = new Help()
		const _cmd_null_KYmc = null;
		const _longestOptionTermLength_function_eHbs = () => { };
		const _longestSubcommandTermLength_function_RRjF = () => { };
		const _longestArgumentTermLength_function_bzlZ = () => { };
		const _helper_object_cEbd = {
			"longestOptionTermLength": _longestOptionTermLength_function_eHbs,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_RRjF,
		"longestArgumentTermLength": _longestArgumentTermLength_function_bzlZ
	}
		const _padWidth_function_addW = await _Help_object_MLOl.padWidth(_cmd_null_KYmc, _helper_object_cEbd)
		const _description_function_pgzZ = () => { };
		const _cmd_object_iqHn = {
			"description": _description_function_pgzZ
	}
		const _subcommandDescription_function_Yhto = await _Help_object_MLOl.subcommandDescription(_cmd_object_iqHn)
		const _cmd_undefined_WrJZ = undefined;
		const _anon_string_lLjo = "mUc3qn6YYvD2WVTmArxlxZvpMX9uCYdjMZt5h8yNFskI1dzHUkOHin8F4Lz0MZzi3Dl5";
		const _helper_array_IRSJ = [_anon_string_lLjo]
		const _longestArgumentTermLength_function_rztg = await _Help_object_MLOl.longestArgumentTermLength(_cmd_undefined_WrJZ, _helper_array_IRSJ)
		const _cmd_string_xyHy = "bC8mmqzr4ceKxhDdyXqYC3amJde6quYGJ7IoDU10RGpKs1pssqx";
		const _commandDescription_function_zcQT = await _Help_object_MLOl.commandDescription(_cmd_string_xyHy)


	});

	it('test for help', async () => {

		const _Help_object_Iwvv = new Help()
		const __argsDescription_object_zLEJ = {
		
	}
		const __args_undefined_uQnF = undefined;
		const _cmd_object_DVQB = {
			"_argsDescription": __argsDescription_object_zLEJ,
		"_args": __args_undefined_uQnF
	}
		const _visibleArguments_function_LCQB = await _Help_object_Iwvv.visibleArguments(_cmd_object_DVQB)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:139:2:::141:3:::4444:4500
		const _Help_object_AgJD = new Help()
		const _description_function_nvRz = () => { };
		const _cmd_object_fdRp = {
			"description": _description_function_nvRz
	}
		const _subcommandDescription_function_aTqm = await _Help_object_AgJD.subcommandDescription(_cmd_object_fdRp)
		const _name_function_kwjY = () => { };
		const _argument_object_YaLt = {
			"name": _name_function_kwjY
	}
		const _argumentTerm_function_tHEf = await _Help_object_AgJD.argumentTerm(_argument_object_YaLt)
		const _argChoices_object_cBhF = {
		
	}
		const _defaultValue_numeric_KRvI = 2.52870136082176;
		const _defaultValueDescription_boolean_wfxS = true;
		const _description_undefined_Gkmz = undefined;
		const _argument_object_txip = {
			"argChoices": _argChoices_object_cBhF,
		"defaultValue": _defaultValue_numeric_KRvI,
		"defaultValueDescription": _defaultValueDescription_boolean_wfxS,
		"description": _description_undefined_Gkmz
	}
		const _argumentDescription_function_okJR = await _Help_object_AgJD.argumentDescription(_argument_object_txip)


	});

	it('test for help', async () => {

		const _Help_object_veXR = new Help()
		const _description_function_KbhC = () => { };
		const _cmd_object_lGbW = {
			"description": _description_function_KbhC
	}
		const _subcommandDescription_function_TDmz = await _Help_object_veXR.subcommandDescription(_cmd_object_lGbW)
		const _cmd_numeric_PUMh = -5.3919508535314975;
		const _visibleArguments_function_uoEi = await _Help_object_veXR.visibleArguments(_cmd_numeric_PUMh)


	});

	it('test for help', async () => {

		const _Help_object_qbma = new Help()
		const _cmd_null_EhsE = null;
		const _visibleCommands_function_kIus = await _Help_object_qbma.visibleCommands(_cmd_null_EhsE)
		const _filter_function_BoQR = () => { };
		const _options_object_zTNm = {
			"filter": _filter_function_BoQR
	}
		const __hasHelpOption_boolean_Rkwz = false;
		const _anon_string_kSPt = "EXcoHbVrqFgN2SOevEO6eRvAsazwqWNH7NsUnHflj39z4zNsRItao4uX4s8kHkyiL4olP";
		const __helpShortFlag_array_lsZQ = [_anon_string_kSPt]
		const __findOption_function_MJFJ = () => { };
		const __helpLongFlag_function_kQnX = () => { };
		const _createOption_function_Bnud = () => { };
		const __helpDescription_numeric_orbl = 4.005180966224479;
		const _anon_string_fYOX = "4nt4jbSpKcLW1JumG6gGGplFJWGyfKNmspIwe2G8wLvPfxYOhmAchy1T6BPo4H6xlDYpdNSTnQKO3IAX3JzB";
		const __helpFlags_array_sBQG = [_anon_string_fYOX]
		const _cmd_object_WvYz = {
			"options": _options_object_zTNm,
		"_hasHelpOption": __hasHelpOption_boolean_Rkwz,
		"_helpShortFlag": __helpShortFlag_array_lsZQ,
		"_findOption": __findOption_function_MJFJ,
		"_helpLongFlag": __helpLongFlag_function_kQnX,
		"createOption": _createOption_function_Bnud,
		"_helpDescription": __helpDescription_numeric_orbl,
		"_helpFlags": __helpFlags_array_sBQG
	}
		const _visibleOptions_function_ITRV = await _Help_object_qbma.visibleOptions(_cmd_object_WvYz)


	});

	it('test for help', async () => {
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:60:4:::70:5:::2141:2583
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:71:4:::79:5:::2588:2971
		const _Help_object_VdfY = new Help()
		const _description_function_ZUNQ = () => { };
		const _cmd_object_JTbN = {
			"description": _description_function_ZUNQ
	}
		const _subcommandDescription_function_oCvs = await _Help_object_VdfY.subcommandDescription(_cmd_object_JTbN)
		const _filter_function_AUhS = () => { };
		const _options_object_vMDt = {
			"filter": _filter_function_AUhS
	}
		const __hasHelpOption_boolean_dZZS = false;
		const __helpShortFlag_string_ZUdK = "2IRfBFgsolTfCYaPsQLcioXhraXgrV3Gj6GneZIKIkYvaykobLpXEQhNPoJYb91q8jE6ruFqj20VG3bb43na4fYEkrDF1Nwuy";
		const __findOption_function_jsLh = () => { };
		const __helpLongFlag_object_juxl = {
		
	}
		const _createOption_function_iyiN = () => { };
		const __helpDescription_function_XaLz = () => { };
		const __helpFlags_undefined_apmX = undefined;
		const _cmd_object_vxUh = {
			"options": _options_object_vMDt,
		"_hasHelpOption": __hasHelpOption_boolean_dZZS,
		"_helpShortFlag": __helpShortFlag_string_ZUdK,
		"_findOption": __findOption_function_jsLh,
		"_helpLongFlag": __helpLongFlag_object_juxl,
		"createOption": _createOption_function_iyiN,
		"_helpDescription": __helpDescription_function_XaLz,
		"_helpFlags": __helpFlags_undefined_apmX
	}
		const _visibleOptions_function_ESUV = await _Help_object_VdfY.visibleOptions(_cmd_object_vxUh)
		const _anon_string_hDnM = "sj6XhTTPiFdy97X413SPnAl8owWeP9GrAGjp1vnqoaWqKQH5oe0dIfHo5a9ND0IknbKQmadOKNjwJTQ9e1v4JxA6";
		const __args_array_zjUw = [_anon_string_hDnM]
		const __name_numeric_QQiI = -0.7766177614425374;
		const _anon_string_RWTj = "oCQqPB8j";
		const __aliases_array_njFS = [_anon_string_RWTj]
		const _options_function_MbDW = () => { };
		const _cmd_object_WFjA = {
			"_args": __args_array_zjUw,
		"_name": __name_numeric_QQiI,
		"_aliases": __aliases_array_njFS,
		"options": _options_function_MbDW
	}
		const _subcommandTerm_function_SkPu = await _Help_object_VdfY.subcommandTerm(_cmd_object_WFjA)
		const _description_function_hQLj = () => { };
		const _cmd_object_BdBY = {
			"description": _description_function_hQLj
	}
		const _commandDescription_function_DsPV = await _Help_object_VdfY.commandDescription(_cmd_object_BdBY)
		const _cmd_function_Nyey = () => { };
		const _visibleCommands_function_DUwZ = () => { };
		const _subcommandTerm_function_HDew = () => { };
		const _helper_object_JKsk = {
			"visibleCommands": _visibleCommands_function_DUwZ,
		"subcommandTerm": _subcommandTerm_function_HDew
	}
		const _longestSubcommandTermLength_function_pqGC = await _Help_object_VdfY.longestSubcommandTermLength(_cmd_function_Nyey, _helper_object_JKsk)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:243:42:::243:76:::6970:7004
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:241:6:::243:92:::6845:7020
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:246:6:::246:106:::7096:7196
		const _Help_object_apUi = new Help()
		const _anon_string_dyYu = "x5q2gdy9rRSQLxLaVfp1xv93iJVcKCQPOtHhnCHi";
		const _argChoices_array_ekde = [_anon_string_dyYu]
		const _negate_undefined_FPTI = undefined;
		const _defaultValue_function_Wygx = () => { };
		const _defaultValueDescription_boolean_xECk = false;
		const _anon_string_dFhu = "weOyi5hz7Sx1VJwPchWT3u2UAa7xdmVf5oj56S40QO5jRUe2VEJN1";
		const _envVar_array_WujB = [_anon_string_dFhu]
		const _description_string_almN = "SaWroYjrsLLstseyvJ0YRasyO2RCaxIJTJWeFdZY3LX5e4lUBtxvjcl3CX3Lsuj3tKhuSrcCaF";
		const _option_object_wGRj = {
			"argChoices": _argChoices_array_ekde,
		"negate": _negate_undefined_FPTI,
		"defaultValue": _defaultValue_function_Wygx,
		"defaultValueDescription": _defaultValueDescription_boolean_xECk,
		"envVar": _envVar_array_WujB,
		"description": _description_string_almN
	}
		const _optionDescription_function_nvSh = await _Help_object_apUi.optionDescription(_option_object_wGRj)
		const _flags_numeric_HMeg = -8.373771550523065;
		const _option_object_xvir = {
			"flags": _flags_numeric_HMeg
	}
		const _optionTerm_function_JBnQ = await _Help_object_apUi.optionTerm(_option_object_xvir)
		const __name_string_EhaU = "RaEGGhpJV8pXe46CD4aBDowxcO9fNULlMyhH4L86nar";
		const _anon_string_fmQE = "sNYBJwMbDXm79EmMuBMnyd4hkrv8WTeEuPPaJb40Vwx1XIJ11HRA1IyeNjE";
		const __aliases_array_zrkr = [_anon_string_fmQE]
		const _parent_function_yisI = () => { };
		const _usage_function_Cpol = () => { };
		const _cmd_object_SYyM = {
			"_name": __name_string_EhaU,
		"_aliases": __aliases_array_zrkr,
		"parent": _parent_function_yisI,
		"usage": _usage_function_Cpol
	}
		const _commandUsage_function_zazB = await _Help_object_apUi.commandUsage(_cmd_object_SYyM)
		const _cmd_function_jSEE = () => { };
		const _visibleOptions_function_qrNW = () => { };
		const _optionTerm_function_JvMf = () => { };
		const _helper_object_kYMW = {
			"visibleOptions": _visibleOptions_function_qrNW,
		"optionTerm": _optionTerm_function_JvMf
	}
		const _longestOptionTermLength_function_IYtW = await _Help_object_apUi.longestOptionTermLength(_cmd_function_jSEE, _helper_object_kYMW)


	});

	it('test for help', async () => {

		const _Help_object_XCMI = new Help()
		const _anon_string_YlgS = "TmFEO9LJjmBR6cfQ2Zm6CFMU";
		const _commands_array_KAQn = [_anon_string_YlgS]
		const __hasImplicitHelpCommand_function_ERAo = () => { };
		const __helpCommandnameAndArgs_string_Hvrb = "QKX73lAHO9VCnepOdw9ssOWycCRMamwSUZw8DwShXDlEYZD5ezrpE2gO8nhePfbeeUEW";
		const _createCommand_function_zVVr = () => { };
		const __helpCommandDescription_string_ppva = "epNJC5agrWyKgP8XnMAo1zqJIav4vMoBJhVn8yL047QTIjGfi";
		const _cmd_object_lyrs = {
			"commands": _commands_array_KAQn,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_function_ERAo,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_string_Hvrb,
		"createCommand": _createCommand_function_zVVr,
		"_helpCommandDescription": __helpCommandDescription_string_ppva
	}
		const _visibleCommands_function_VPdD = await _Help_object_XCMI.visibleCommands(_cmd_object_lyrs)
		const _cmd_undefined_TSAq = undefined;
		const _padWidth_object_TcDr = {
		
	}
		const _helpWidth_numeric_XziP = -8.22526407028357;
		const _wrap_function_Cmfy = () => { };
		const _commandUsage_function_ghqU = () => { };
		const _commandDescription_function_PnWW = () => { };
		const _visibleArguments_function_nvNa = () => { };
		const _argumentTerm_function_HBuV = () => { };
		const _argumentDescription_function_aQPy = () => { };
		const _visibleOptions_function_QErL = () => { };
		const _optionTerm_function_TAtA = () => { };
		const _optionDescription_boolean_IkRR = false;
		const _visibleCommands_function_vcWw = () => { };
		const _subcommandTerm_function_fBWk = () => { };
		const _subcommandDescription_function_abtU = () => { };
		const _helper_object_xhVG = {
			"padWidth": _padWidth_object_TcDr,
		"helpWidth": _helpWidth_numeric_XziP,
		"wrap": _wrap_function_Cmfy,
		"commandUsage": _commandUsage_function_ghqU,
		"commandDescription": _commandDescription_function_PnWW,
		"visibleArguments": _visibleArguments_function_nvNa,
		"argumentTerm": _argumentTerm_function_HBuV,
		"argumentDescription": _argumentDescription_function_aQPy,
		"visibleOptions": _visibleOptions_function_QErL,
		"optionTerm": _optionTerm_function_TAtA,
		"optionDescription": _optionDescription_boolean_IkRR,
		"visibleCommands": _visibleCommands_function_vcWw,
		"subcommandTerm": _subcommandTerm_function_fBWk,
		"subcommandDescription": _subcommandDescription_function_abtU
	}
		const _formatHelp_function_VcVz = await _Help_object_XCMI.formatHelp(_cmd_undefined_TSAq, _helper_object_xhVG)
		const _anon_string_FYdn = "6datW9WstY6gXpceDBUuDc8saNPL5FyRJ6ucTAvDsAA7nMxCLk868BYS8FH7Cx";
		const _argChoices_array_ABDo = [_anon_string_FYdn]
		const _negate_object_waIk = {
		
	}
		const _defaultValue_boolean_dZZh = true;
		const _defaultValueDescription_boolean_KtUc = true;
		const _envVar_string_pJVA = "Vnzp6XanHgQ5lwCaIP";
		const _description_function_kuHT = () => { };
		const _option_object_oeVs = {
			"argChoices": _argChoices_array_ABDo,
		"negate": _negate_object_waIk,
		"defaultValue": _defaultValue_boolean_dZZh,
		"defaultValueDescription": _defaultValueDescription_boolean_KtUc,
		"envVar": _envVar_string_pJVA,
		"description": _description_function_kuHT
	}
		const _optionDescription_function_sbRL = await _Help_object_XCMI.optionDescription(_option_object_oeVs)


	});

	it('test for help', async () => {

		const _Help_object_sPxj = new Help()
		const _cmd_function_HGud = () => { };
		const _longestOptionTermLength_function_ZftO = () => { };
		const _longestSubcommandTermLength_function_phyv = () => { };
		const _longestArgumentTermLength_function_jZOE = () => { };
		const _helper_object_YpEN = {
			"longestOptionTermLength": _longestOptionTermLength_function_ZftO,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_phyv,
		"longestArgumentTermLength": _longestArgumentTermLength_function_jZOE
	}
		const _padWidth_function_UZZu = await _Help_object_sPxj.padWidth(_cmd_function_HGud, _helper_object_YpEN)
		const _description_numeric_VuVk = 3.6602982360758;
		const _cmd_object_qrRN = {
			"description": _description_numeric_VuVk
	}
		const _subcommandDescription_function_CuoJ = await _Help_object_sPxj.subcommandDescription(_cmd_object_qrRN)
		const __name_numeric_Mzmb = 8.93371592398233;
		const _anon_string_tnPW = "ED1W1iOjuJubeu88bEjcIMegIirclWzsreQoAlIBqPel1rdAH1lQNPaM72iJBzr7Cl2DgxeaELrvhAXlQOJeEENMGP";
		const __aliases_array_RDLG = [_anon_string_tnPW]
		const _parent_function_VkQj = () => { };
		const _usage_numeric_LHnp = 2.418642096697287;
		const _cmd_object_DarX = {
			"_name": __name_numeric_Mzmb,
		"_aliases": __aliases_array_RDLG,
		"parent": _parent_function_VkQj,
		"usage": _usage_numeric_LHnp
	}
		const _commandUsage_function_AakR = await _Help_object_sPxj.commandUsage(_cmd_object_DarX)


	});

	it('test for help', async () => {
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:267:4:::271:5:::7639:7855
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:272:4:::274:5:::7860:8019
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:275:4:::281:5:::8024:8249
		const _Help_object_jMaX = new Help()
		const _flags_boolean_gxRw = true;
		const _option_object_xEET = {
			"flags": _flags_boolean_gxRw
	}
		const _optionTerm_function_lkGc = await _Help_object_jMaX.optionTerm(_option_object_xEET)
		const _description_function_NlRA = () => { };
		const _cmd_object_aQPU = {
			"description": _description_function_NlRA
	}
		const _subcommandDescription_function_kQPi = await _Help_object_jMaX.subcommandDescription(_cmd_object_aQPU)
		const _argument_boolean_TsMR = false;
		const _argumentDescription_function_rSDk = await _Help_object_jMaX.argumentDescription(_argument_boolean_TsMR)
		const _anon_string_zqAA = "44hQWyVamG4sS0Qxl9wAiuC2i4RXR1aslAc";
		const _argChoices_array_tYlD = [_anon_string_zqAA]
		const _negate_null_MbIa = null;
		const _defaultValue_string_FzHB = "RhJxKXLtwr7KHpcg7g97jKQIS6iBfM1WQqfSHpjLghJMI0kyUTt2mOPY2jvawWUNNYrm7geBlKelICe55G26TShiYzMYsp";
		const _defaultValueDescription_boolean_qnFf = false;
		const _envVar_null_LyhC = null;
		const _description_boolean_dqpe = true;
		const _option_object_fnUw = {
			"argChoices": _argChoices_array_tYlD,
		"negate": _negate_null_MbIa,
		"defaultValue": _defaultValue_string_FzHB,
		"defaultValueDescription": _defaultValueDescription_boolean_qnFf,
		"envVar": _envVar_null_LyhC,
		"description": _description_boolean_dqpe
	}
		const _optionDescription_function_BiLf = await _Help_object_jMaX.optionDescription(_option_object_fnUw)
		const _anon_string_wMpT = "pp4X2uUX8axjSAUoqheVytG6jKAkEnyJJ7oPov3n0Nji3eClwRBh";
		const _options_array_jrkm = [_anon_string_wMpT]
		const __hasHelpOption_boolean_rCdv = false;
		const __helpShortFlag_numeric_acBx = -0.014243810519094069;
		const _anon_string_eFcu = "TC9RgniDgIyQBDOkyoSXl";
		const __findOption_array_hadH = [_anon_string_eFcu]
		const __helpLongFlag_string_unLn = "uhniAS1ODwpFyKIyubdT4KaMXOotzj4QlABowhb8CYsOwUysvVTSDuC2O7KeW1RbgLj9";
		const _createOption_function_temW = () => { };
		const __helpDescription_string_jJNQ = "DuDQw";
		const __helpFlags_object_Fpni = {
		
	}
		const _cmd_object_vQTS = {
			"options": _options_array_jrkm,
		"_hasHelpOption": __hasHelpOption_boolean_rCdv,
		"_helpShortFlag": __helpShortFlag_numeric_acBx,
		"_findOption": __findOption_array_hadH,
		"_helpLongFlag": __helpLongFlag_string_unLn,
		"createOption": _createOption_function_temW,
		"_helpDescription": __helpDescription_string_jJNQ,
		"_helpFlags": __helpFlags_object_Fpni
	}
		const _visibleOptions_function_nsBA = await _Help_object_jMaX.visibleOptions(_cmd_object_vQTS)


	});

	it('test for help', async () => {

		const _Help_object_npEf = new Help()
		const _argument_function_RcNt = () => { };
		const _argumentTerm_function_KTgs = await _Help_object_npEf.argumentTerm(_argument_function_RcNt)
		const _anon_string_gxWZ = "RSKCwIXhKT5R2hIHC8lmCy";
		const _commands_array_Pqce = [_anon_string_gxWZ]
		const __hasImplicitHelpCommand_function_VATC = () => { };
		const __helpCommandnameAndArgs_string_zqwE = "f6v0";
		const _createCommand_function_MFBX = () => { };
		const __helpCommandDescription_boolean_utZg = true;
		const _cmd_object_YlWA = {
			"commands": _commands_array_Pqce,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_function_VATC,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_string_zqwE,
		"createCommand": _createCommand_function_MFBX,
		"_helpCommandDescription": __helpCommandDescription_boolean_utZg
	}
		const _visibleCommands_function_fiLr = await _Help_object_npEf.visibleCommands(_cmd_object_YlWA)
		const _argChoices_object_jELX = {
		
	}
		const _defaultValue_boolean_cukX = true;
		const _defaultValueDescription_boolean_Bohk = false;
		const _description_string_fsOb = "bkItonf9TbCL2wksTAXC8t48krYPyTcedtAWH3oOwhajj1EK4fbU4zBbBjR";
		const _argument_object_Yatq = {
			"argChoices": _argChoices_object_jELX,
		"defaultValue": _defaultValue_boolean_cukX,
		"defaultValueDescription": _defaultValueDescription_boolean_Bohk,
		"description": _description_string_fsOb
	}
		const _argumentDescription_function_Nflm = await _Help_object_npEf.argumentDescription(_argument_object_Yatq)


	});

	it('test for help', async () => {

		const _Help_object_veNt = new Help()
		const _cmd_null_YgAg = null;
		const _commandUsage_function_vTlE = await _Help_object_veNt.commandUsage(_cmd_null_YgAg)
		const _argument_function_Wpla = () => { };
		const _argumentTerm_function_JDWB = await _Help_object_veNt.argumentTerm(_argument_function_Wpla)
		const _name_function_flMS = () => { };
		const _argument_object_HUsS = {
			"name": _name_function_flMS
	}
		const _argumentTerm_function_Pzew = await _Help_object_veNt.argumentTerm(_argument_object_HUsS)
		const _cmd_null_YYro = null;
		const _visibleArguments_function_wxyI = () => { };
		const _argumentTerm_function_BBnE = () => { };
		const _helper_object_HJBG = {
			"visibleArguments": _visibleArguments_function_wxyI,
		"argumentTerm": _argumentTerm_function_BBnE
	}
		const _longestArgumentTermLength_function_AyhE = await _Help_object_veNt.longestArgumentTermLength(_cmd_null_YYro, _helper_object_HJBG)


	});

	it('test for help', async () => {

		const _Help_object_kqhw = new Help()
		const _map_function_fGAM = () => { };
		const _argChoices_object_Wycy = {
			"map": _map_function_fGAM
	}
		const _negate_object_nvfQ = {
		
	}
		const _defaultValue_function_hzpO = () => { };
		const _defaultValueDescription_boolean_ZjZV = false;
		const _envVar_function_bbXd = () => { };
		const _description_object_CcrY = {
		
	}
		const _option_object_YLvr = {
			"argChoices": _argChoices_object_Wycy,
		"negate": _negate_object_nvfQ,
		"defaultValue": _defaultValue_function_hzpO,
		"defaultValueDescription": _defaultValueDescription_boolean_ZjZV,
		"envVar": _envVar_function_bbXd,
		"description": _description_object_CcrY
	}
		const _optionDescription_function_wCqH = await _Help_object_kqhw.optionDescription(_option_object_YLvr)
		const _filter_null_mLDn = null;
		const _options_object_RhuG = {
			"filter": _filter_null_mLDn
	}
		const __hasHelpOption_boolean_aYWT = false;
		const __helpShortFlag_object_XrGA = {
		
	}
		const _anon_string_YoJV = "Mu1XUariEA6MM1rbf";
		const __findOption_array_EytN = [_anon_string_YoJV]
		const __helpLongFlag_string_UzcQ = "j7WutrKcmNZcIjEUrGk4HU7X";
		const _createOption_function_nUNi = () => { };
		const __helpDescription_numeric_glHT = 2.132061441372013;
		const __helpFlags_undefined_ZOnW = undefined;
		const _cmd_object_nKvn = {
			"options": _options_object_RhuG,
		"_hasHelpOption": __hasHelpOption_boolean_aYWT,
		"_helpShortFlag": __helpShortFlag_object_XrGA,
		"_findOption": __findOption_array_EytN,
		"_helpLongFlag": __helpLongFlag_string_UzcQ,
		"createOption": _createOption_function_nUNi,
		"_helpDescription": __helpDescription_numeric_glHT,
		"_helpFlags": __helpFlags_undefined_ZOnW
	}
		const _visibleOptions_function_ogyr = await _Help_object_kqhw.visibleOptions(_cmd_object_nKvn)
		const _map_function_gJkk = () => { };
		const _argChoices_object_jtZw = {
			"map": _map_function_gJkk
	}
		const _negate_undefined_oWmI = undefined;
		const _defaultValue_null_JrRb = null;
		const _defaultValueDescription_boolean_xLPC = false;
		const _anon_string_yBvX = "tNRIkf5p2IegMR7AcD56FdN7XrylJ7plQDZ3stCfTSV4opQsESjJKz1d9z6hQou3B9ihKEwyfp3sT8l2TF";
		const _envVar_array_hQML = [_anon_string_yBvX]
		const _description_boolean_XrXk = false;
		const _option_object_fbTM = {
			"argChoices": _argChoices_object_jtZw,
		"negate": _negate_undefined_oWmI,
		"defaultValue": _defaultValue_null_JrRb,
		"defaultValueDescription": _defaultValueDescription_boolean_xLPC,
		"envVar": _envVar_array_hQML,
		"description": _description_boolean_XrXk
	}
		const _optionDescription_function_ppai = await _Help_object_kqhw.optionDescription(_option_object_fbTM)
		const _anon_string_KxMO = "Y";
		const _commands_array_oauv = [_anon_string_KxMO]
		const __hasImplicitHelpCommand_function_POfp = () => { };
		const __helpCommandnameAndArgs_string_NetN = "";
		const _createCommand_function_DuhL = () => { };
		const __helpCommandDescription_object_SEuq = {
		
	}
		const _cmd_object_MZSt = {
			"commands": _commands_array_oauv,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_function_POfp,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_string_NetN,
		"createCommand": _createCommand_function_DuhL,
		"_helpCommandDescription": __helpCommandDescription_object_SEuq
	}
		const _visibleCommands_function_fnWP = await _Help_object_kqhw.visibleCommands(_cmd_object_MZSt)
		const _description_function_SjVE = () => { };
		const _cmd_object_ExCy = {
			"description": _description_function_SjVE
	}
		const _subcommandDescription_function_aPwS = await _Help_object_kqhw.subcommandDescription(_cmd_object_ExCy)


	});

	it('test for help', async () => {

		const _Help_object_kfnM = new Help()
		const _match_function_oCXw = () => { };
		const _substr_function_sClN = () => { };
		const _str_object_qzHW = {
			"match": _match_function_oCXw,
		"substr": _substr_function_sClN
	}
		const _width_numeric_NmtC = 2.0388719505242765;
		const _indent_numeric_kLkV = 0.47394049712502273;
		const _Assignment_numeric_nRTT = -6.858596639387802;
		const _wrap_function_rLGY = await _Help_object_kfnM.wrap(_str_object_qzHW, _width_numeric_NmtC, _indent_numeric_kLkV, _Assignment_numeric_nRTT)
		const _anon_string_ZcLJ = "e9MP4Wa5HQYGAjlWWXcxXGgcHdzofbwRRHQu";
		const __args_array_klsm = [_anon_string_ZcLJ]
		const __name_string_pdDx = "N75befEbhy6uKDQmo0TYYnVqfurU3m7mAsgaVC7sHBxHXv4HEirXcOIND61gIixi75YHYzQOZC6wlsN2IlUEaF98Ec";
		const _anon_string_lzrd = "8eVDFWMLB26Qvq8tl6pE9kLAEok5uBobAvce23md";
		const __aliases_array_nSYw = [_anon_string_lzrd]
		const _options_function_pkxf = () => { };
		const _cmd_object_EMyk = {
			"_args": __args_array_klsm,
		"_name": __name_string_pdDx,
		"_aliases": __aliases_array_nSYw,
		"options": _options_function_pkxf
	}
		const _subcommandTerm_function_PBEr = await _Help_object_kfnM.subcommandTerm(_cmd_object_EMyk)
		const _anon_string_wfAZ = "4FxGIlqrOpwfFqGtcyv9Z7D4KsqwoK8InwMspX29nmR6bOjUn3HnZ89ieJYcKe";
		const _options_array_sHOw = [_anon_string_wfAZ]
		const __hasHelpOption_boolean_PGvA = true;
		const __helpShortFlag_null_KdwM = null;
		const _anon_string_fZPy = "OlJsksywArVHXrHOcCrPde4ERFviG2oElE87eLZUSldwjpNdHPKQAoPMfgnxobEqoWOH5kpVR2aQ1roM9Bw";
		const __findOption_array_LdTo = [_anon_string_fZPy]
		const __helpLongFlag_function_iRPX = () => { };
		const _createOption_function_BowU = () => { };
		const __helpDescription_boolean_SJUo = true;
		const _anon_string_FLWo = "Nu5Mg";
		const __helpFlags_array_BQnC = [_anon_string_FLWo]
		const _cmd_object_UHzn = {
			"options": _options_array_sHOw,
		"_hasHelpOption": __hasHelpOption_boolean_PGvA,
		"_helpShortFlag": __helpShortFlag_null_KdwM,
		"_findOption": __findOption_array_LdTo,
		"_helpLongFlag": __helpLongFlag_function_iRPX,
		"createOption": _createOption_function_BowU,
		"_helpDescription": __helpDescription_boolean_SJUo,
		"_helpFlags": __helpFlags_array_BQnC
	}
		const _visibleOptions_function_RSot = await _Help_object_kfnM.visibleOptions(_cmd_object_UHzn)


	});

	it('test for help', async () => {
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:248:4:::250:5:::7207:7294
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:251:4:::253:5:::7299:7396
		const _Help_object_fOXJ = new Help()
		const _option_string_GwqS = "RD57cavPGxv4qDYzJyKchZgc6jFw9IfOa43YpwMIutbphvjJHxGzn5ixTWiojDTRYklsyicyh1dqJY1rd6OPnw2Ldqg2";
		const _optionDescription_function_vfCU = await _Help_object_fOXJ.optionDescription(_option_string_GwqS)
		const _description_function_mmKX = () => { };
		const _cmd_object_EBQU = {
			"description": _description_function_mmKX
	}
		const _subcommandDescription_function_Uqcn = await _Help_object_fOXJ.subcommandDescription(_cmd_object_EBQU)


	});

	it('test for help', async () => {

		const _Help_object_Bxmx = new Help()
		const _cmd_function_YMUy = () => { };
		const _helper_boolean_aPNN = true;
		const _longestOptionTermLength_function_KTLR = await _Help_object_Bxmx.longestOptionTermLength(_cmd_function_YMUy, _helper_boolean_aPNN)
		const _name_object_LHlu = {
		
	}
		const _argument_object_VUUG = {
			"name": _name_object_LHlu
	}
		const _argumentTerm_function_GrVs = await _Help_object_Bxmx.argumentTerm(_argument_object_VUUG)
		const _match_function_SHLL = () => { };
		const _substr_function_CRbH = () => { };
		const _str_object_Jmqd = {
			"match": _match_function_SHLL,
		"substr": _substr_function_CRbH
	}
		const _width_numeric_IkkN = 5.127549770340272;
		const _indent_numeric_gKho = -3.6506629803301855;
		const _Assignment_numeric_GcIG = 5.23325138428002;
		const _wrap_function_lDAM = await _Help_object_Bxmx.wrap(_str_object_Jmqd, _width_numeric_IkkN, _indent_numeric_gKho, _Assignment_numeric_GcIG)
		const _cmd_numeric_AKdp = 6.41333183500144;
		const _visibleCommands_function_otmM = () => { };
		const _subcommandTerm_function_UllW = () => { };
		const _helper_object_uxIm = {
			"visibleCommands": _visibleCommands_function_otmM,
		"subcommandTerm": _subcommandTerm_function_UllW
	}
		const _longestSubcommandTermLength_function_HaEP = await _Help_object_Bxmx.longestSubcommandTermLength(_cmd_numeric_AKdp, _helper_object_uxIm)


	});

	it('test for help', async () => {

		const _Help_object_WlrR = new Help()
		const _argument_null_pVJj = null;
		const _argumentTerm_function_ujtz = await _Help_object_WlrR.argumentTerm(_argument_null_pVJj)
		const _match_function_xWoM = () => { };
		const _substr_function_rBYu = () => { };
		const _str_object_AwZR = {
			"match": _match_function_xWoM,
		"substr": _substr_function_rBYu
	}
		const _width_numeric_CREX = -8.019851873595883;
		const _indent_numeric_bMmT = 2.9673880523032903;
		const _Assignment_numeric_VRfg = 6.260665282557216;
		const _wrap_function_XRpG = await _Help_object_WlrR.wrap(_str_object_AwZR, _width_numeric_CREX, _indent_numeric_bMmT, _Assignment_numeric_VRfg)
		const _cmd_function_Fdby = () => { };
		const _visibleOptions_function_DxbT = () => { };
		const _optionTerm_function_UeSH = () => { };
		const _helper_object_igSr = {
			"visibleOptions": _visibleOptions_function_DxbT,
		"optionTerm": _optionTerm_function_UeSH
	}
		const _longestOptionTermLength_function_zBGT = await _Help_object_WlrR.longestOptionTermLength(_cmd_function_Fdby, _helper_object_igSr)


	});

	it('test for help', async () => {
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:195:4:::197:5:::5691:5768
		const _Help_object_MfQz = new Help()
		const _description_function_CHfw = () => { };
		const _cmd_object_bJsw = {
			"description": _description_function_CHfw
	}
		const _subcommandDescription_function_IxCn = await _Help_object_MfQz.subcommandDescription(_cmd_object_bJsw)
		const __name_string_UriO = "yBXNciKwPIdrsa6U2yyi";
		const __aliases_numeric_DwBd = -6.706270069133055;
		const _parent_numeric_WrPb = -3.420548063935893;
		const _usage_function_Vbus = () => { };
		const _cmd_object_MWwZ = {
			"_name": __name_string_UriO,
		"_aliases": __aliases_numeric_DwBd,
		"parent": _parent_numeric_WrPb,
		"usage": _usage_function_Vbus
	}
		const _commandUsage_function_OKfW = await _Help_object_MfQz.commandUsage(_cmd_object_MWwZ)
		const _cmd_function_pdXX = () => { };
		const _longestOptionTermLength_function_jDxV = () => { };
		const _longestSubcommandTermLength_function_FkTm = () => { };
		const _longestArgumentTermLength_function_rRBq = () => { };
		const _helper_object_DicX = {
			"longestOptionTermLength": _longestOptionTermLength_function_jDxV,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_FkTm,
		"longestArgumentTermLength": _longestArgumentTermLength_function_rRBq
	}
		const _padWidth_function_DgDa = await _Help_object_MfQz.padWidth(_cmd_function_pdXX, _helper_object_DicX)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:379:38:::379:49:::11378:11389
		const _Help_object_NWVu = new Help()
		const _match_function_QsXG = () => { };
		const _substr_function_kHQp = () => { };
		const _str_object_DwIJ = {
			"match": _match_function_QsXG,
		"substr": _substr_function_kHQp
	}
		const _width_numeric_BVYP = -2.6090515613065746;
		const _indent_numeric_PFOL = 3.139046296678032;
		const _Assignment_numeric_WvBX = 3.37519045147622;
		const _wrap_function_tosy = await _Help_object_NWVu.wrap(_str_object_DwIJ, _width_numeric_BVYP, _indent_numeric_PFOL, _Assignment_numeric_WvBX)
		const _name_function_XwbS = () => { };
		const _argument_object_RXaG = {
			"name": _name_function_XwbS
	}
		const _argumentTerm_function_oCcl = await _Help_object_NWVu.argumentTerm(_argument_object_RXaG)
		const _cmd_function_kxIZ = () => { };
		const _visibleOptions_function_Byps = () => { };
		const _optionTerm_function_OgKe = () => { };
		const _helper_object_qTTt = {
			"visibleOptions": _visibleOptions_function_Byps,
		"optionTerm": _optionTerm_function_OgKe
	}
		const _longestOptionTermLength_function_PGgU = await _Help_object_NWVu.longestOptionTermLength(_cmd_function_kxIZ, _helper_object_qTTt)
		const _cmd_boolean_YwsM = true;
		const _padWidth_function_Yojz = () => { };
		const _helpWidth_boolean_dgrx = false;
		const _wrap_function_Jwmk = () => { };
		const _commandUsage_function_IqOq = () => { };
		const _commandDescription_string_BUrV = "p9khFjIAmoJCd58gh4t2uOKf1O";
		const _visibleArguments_string_bBTi = "gvybzkKUe";
		const _argumentTerm_function_cfXN = () => { };
		const _argumentDescription_function_uijv = () => { };
		const _visibleOptions_function_yQfo = () => { };
		const _optionTerm_function_iecq = () => { };
		const _optionDescription_function_FXwS = () => { };
		const _anon_string_QEfp = "OXn6e1LOf7z1r6pUJn95NiIXJTDxVNxwLt9HrhBsmWC3T1i76FhCzJzjyDArtBdF7va5xLYK4e485IqVuutdnLh8I";
		const _visibleCommands_array_cOoH = [_anon_string_QEfp]
		const _subcommandTerm_boolean_voxE = false;
		const _subcommandDescription_function_rQSD = () => { };
		const _helper_object_GZxV = {
			"padWidth": _padWidth_function_Yojz,
		"helpWidth": _helpWidth_boolean_dgrx,
		"wrap": _wrap_function_Jwmk,
		"commandUsage": _commandUsage_function_IqOq,
		"commandDescription": _commandDescription_string_BUrV,
		"visibleArguments": _visibleArguments_string_bBTi,
		"argumentTerm": _argumentTerm_function_cfXN,
		"argumentDescription": _argumentDescription_function_uijv,
		"visibleOptions": _visibleOptions_function_yQfo,
		"optionTerm": _optionTerm_function_iecq,
		"optionDescription": _optionDescription_function_FXwS,
		"visibleCommands": _visibleCommands_array_cOoH,
		"subcommandTerm": _subcommandTerm_boolean_voxE,
		"subcommandDescription": _subcommandDescription_function_rQSD
	}
		const _formatHelp_function_DwBE = await _Help_object_NWVu.formatHelp(_cmd_boolean_YwsM, _helper_object_GZxV)
		const _anon_string_NUYe = "lFsBhSuX7uVGk6GhrBttizPkdMlJbxuoafKKvoedTJGTFmbFyN1zsLXKEgiP7qrQw2xShb8A8xuU9BC";
		const _argChoices_array_Uiir = [_anon_string_NUYe]
		const _defaultValue_numeric_UEvA = -4.918418628800046;
		const _defaultValueDescription_boolean_FYAJ = true;
		const _description_string_WFKd = "JvPRoafZIyCwPk6yAOK1GSbLsI6tCXLYOqWOCpIdhD3uMoO6hjpjCX0WV6o4s2gbBlx";
		const _argument_object_TDKF = {
			"argChoices": _argChoices_array_Uiir,
		"defaultValue": _defaultValue_numeric_UEvA,
		"defaultValueDescription": _defaultValueDescription_boolean_FYAJ,
		"description": _description_string_WFKd
	}
		const _argumentDescription_function_kalv = await _Help_object_NWVu.argumentDescription(_argument_object_TDKF)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:61:6:::61:21:::2192:2207
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:64:13:::68:7:::2333:2538
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:67:8:::67:76:::2462:2530
		const _Help_object_WIPM = new Help()
		const _anon_string_EVyj = "pgA38HHwWIoy9E5Sum4Ni84Ji9XLfbdqOldw7";
		const _options_array_dvpT = [_anon_string_EVyj]
		const __hasHelpOption_boolean_QbiS = true;
		const _anon_string_HFTD = "QhYX80PHVzUGlQnhj7mDVnUYVo7O0kP5yywGOsoDxmwo6rbzlgrjWfwc18";
		const __helpShortFlag_array_OSPo = [_anon_string_HFTD]
		const __findOption_function_VPPF = () => { };
		const __helpLongFlag_string_NOWE = "cAjQn67qYSHoFQcX0A8LJIwjr7xAALUCJcB11HZoycn";
		const _createOption_function_GoJD = () => { };
		const __helpDescription_function_sNlq = () => { };
		const __helpFlags_function_dYwB = () => { };
		const _cmd_object_JLEY = {
			"options": _options_array_dvpT,
		"_hasHelpOption": __hasHelpOption_boolean_QbiS,
		"_helpShortFlag": __helpShortFlag_array_OSPo,
		"_findOption": __findOption_function_VPPF,
		"_helpLongFlag": __helpLongFlag_string_NOWE,
		"createOption": _createOption_function_GoJD,
		"_helpDescription": __helpDescription_function_sNlq,
		"_helpFlags": __helpFlags_function_dYwB
	}
		const _visibleOptions_function_ERqY = await _Help_object_WIPM.visibleOptions(_cmd_object_JLEY)
		const _cmd_numeric_HOvK = 6.112177393937589;
		const _visibleCommands_function_kDYh = () => { };
		const _subcommandTerm_function_JIaS = () => { };
		const _helper_object_coGB = {
			"visibleCommands": _visibleCommands_function_kDYh,
		"subcommandTerm": _subcommandTerm_function_JIaS
	}
		const _longestSubcommandTermLength_function_jYYb = await _Help_object_WIPM.longestSubcommandTermLength(_cmd_numeric_HOvK, _helper_object_coGB)


	});

	it('test for help', async () => {

		const _Help_object_dquq = new Help()
		const _cmd_function_GqLq = () => { };
		const _visibleOptions_function_CvGe = await _Help_object_dquq.visibleOptions(_cmd_function_GqLq)
		const _str_numeric_juQM = -6.110520274381736;
		const _width_numeric_LSRR = 8.464315039643004;
		const _indent_numeric_EuIx = 1.9484736444776;
		const _Assignment_numeric_QbaT = 2.797317554614846;
		const _wrap_function_Uhoy = await _Help_object_dquq.wrap(_str_numeric_juQM, _width_numeric_LSRR, _indent_numeric_EuIx, _Assignment_numeric_QbaT)
		const _name_function_mnlo = () => { };
		const _argument_object_QmEH = {
			"name": _name_function_mnlo
	}
		const _argumentTerm_function_Axid = await _Help_object_dquq.argumentTerm(_argument_object_QmEH)


	});

	it('test for help', async () => {

		const _Help_object_PpAj = new Help()
		const __name_string_HuBN = "YhDZd0dNuuRukZvyCFUqA4GGKRH0FilFUvRRdMPCkoyuzTNDA5PICsTUR";
		const __aliases_null_gSGn = null;
		const _parent_function_ozjt = () => { };
		const _usage_function_CmHU = () => { };
		const _cmd_object_HKzB = {
			"_name": __name_string_HuBN,
		"_aliases": __aliases_null_gSGn,
		"parent": _parent_function_ozjt,
		"usage": _usage_function_CmHU
	}
		const _commandUsage_function_jiDx = await _Help_object_PpAj.commandUsage(_cmd_object_HKzB)
		const _cmd_null_UKYs = null;
		const _visibleArguments_function_JsQP = () => { };
		const _argumentTerm_function_TbiL = () => { };
		const _helper_object_kpmR = {
			"visibleArguments": _visibleArguments_function_JsQP,
		"argumentTerm": _argumentTerm_function_TbiL
	}
		const _longestArgumentTermLength_function_HkcC = await _Help_object_PpAj.longestArgumentTermLength(_cmd_null_UKYs, _helper_object_kpmR)
		const _anon_string_RxWD = "sl64N5CQVGGALxjt4KwVJQcLAWUviG1TZChvjMhrIdDUllxFjrkhbYAlp24pthWA70ceUb6mY61";
		const _commands_array_Jlqk = [_anon_string_RxWD]
		const __hasImplicitHelpCommand_function_yQHn = () => { };
		const __helpCommandnameAndArgs_string_mGOI = "GlcR7Ugzt9TV";
		const _createCommand_function_wRiP = () => { };
		const __helpCommandDescription_undefined_zipc = undefined;
		const _cmd_object_JFzt = {
			"commands": _commands_array_Jlqk,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_function_yQHn,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_string_mGOI,
		"createCommand": _createCommand_function_wRiP,
		"_helpCommandDescription": __helpCommandDescription_undefined_zipc
	}
		const _visibleCommands_function_HJRS = await _Help_object_PpAj.visibleCommands(_cmd_object_JFzt)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:63:8:::63:79:::2248:2319
		const _Help_object_Thkl = new Help()
		const _anon_string_CelM = "sNrGTWgVbNp6d";
		const _options_array_Rbza = [_anon_string_CelM]
		const __hasHelpOption_boolean_PheA = true;
		const __helpShortFlag_null_akVG = null;
		const __findOption_function_YJUZ = () => { };
		const __helpLongFlag_boolean_gsWC = true;
		const _createOption_function_Kwci = () => { };
		const __helpDescription_string_yCcM = "Fyy7q2Fa1geW8Aan2uka1KZDSbDLw7Epw3jGU5qdipX35E5Ma3";
		const __helpFlags_boolean_HHAf = false;
		const _cmd_object_nTsI = {
			"options": _options_array_Rbza,
		"_hasHelpOption": __hasHelpOption_boolean_PheA,
		"_helpShortFlag": __helpShortFlag_null_akVG,
		"_findOption": __findOption_function_YJUZ,
		"_helpLongFlag": __helpLongFlag_boolean_gsWC,
		"createOption": _createOption_function_Kwci,
		"_helpDescription": __helpDescription_string_yCcM,
		"_helpFlags": __helpFlags_boolean_HHAf
	}
		const _visibleOptions_function_SCLz = await _Help_object_Thkl.visibleOptions(_cmd_object_nTsI)
		const __args_string_kPYV = "j0kWEfwwoB77YhLU4rF7wB74kL361gwaylTqTIdpUAFL5eCMIjQRkB3BVQrrbyKg7w";
		const __name_string_DZnk = "oMqppRxOJQPHypcsCdeGBf1uyTkDhRAFeMftAGEmOw1rKYxp5CvIaq";
		const _anon_string_ATET = "oxKjwfRD7CCKbHg1VPY1eu3mmrsa7gvB3aN9hHF76czQKxF6BAQqDP7Mh7l6zeA5hBRJQR9EmSYw2LemcXKudNw";
		const __aliases_array_xyMU = [_anon_string_ATET]
		const _options_function_cDBH = () => { };
		const _cmd_object_GcEU = {
			"_args": __args_string_kPYV,
		"_name": __name_string_DZnk,
		"_aliases": __aliases_array_xyMU,
		"options": _options_function_cDBH
	}
		const _subcommandTerm_function_rNXq = await _Help_object_Thkl.subcommandTerm(_cmd_object_GcEU)
		const _description_function_CXlF = () => { };
		const _cmd_object_HlZx = {
			"description": _description_function_CXlF
	}
		const _subcommandDescription_function_WChj = await _Help_object_Thkl.subcommandDescription(_cmd_object_HlZx)
		const _argument_function_OGwB = () => { };
		const _argumentTerm_function_iRFG = await _Help_object_Thkl.argumentTerm(_argument_function_OGwB)
		const __argsDescription_string_VQSv = "q3yBT1kAsTF9EoxVpQtuOunuXrw6uWsOzdulvXKNXrln9SDYpzouPv8V";
		const __args_function_Nuew = () => { };
		const _cmd_object_Abpd = {
			"_argsDescription": __argsDescription_string_VQSv,
		"_args": __args_function_Nuew
	}
		const _visibleArguments_function_WkWu = await _Help_object_Thkl.visibleArguments(_cmd_object_Abpd)


	});

	it('test for help', async () => {

		const _Help_object_GHGa = new Help()
		const _option_undefined_SXHq = undefined;
		const _optionTerm_function_gVVm = await _Help_object_GHGa.optionTerm(_option_undefined_SXHq)
		const __name_string_yHhS = "k2l7Jyq8BzEaa";
		const _anon_string_AiUH = "DZH3X2pa4NT";
		const __aliases_array_UTGg = [_anon_string_AiUH]
		const _parent_function_SzTv = () => { };
		const _usage_function_eZUJ = () => { };
		const _cmd_object_lbgO = {
			"_name": __name_string_yHhS,
		"_aliases": __aliases_array_UTGg,
		"parent": _parent_function_SzTv,
		"usage": _usage_function_eZUJ
	}
		const _commandUsage_function_FXHn = await _Help_object_GHGa.commandUsage(_cmd_object_lbgO)
		const __name_string_UNbo = "M";
		const _anon_string_XiGU = "yfzKlcBihLFFH2nXa39DxmSHB89ybk";
		const __aliases_array_YLVe = [_anon_string_XiGU]
		const _parent_function_Veot = () => { };
		const _usage_function_saLq = () => { };
		const _cmd_object_uiAZ = {
			"_name": __name_string_UNbo,
		"_aliases": __aliases_array_YLVe,
		"parent": _parent_function_Veot,
		"usage": _usage_function_saLq
	}
		const _commandUsage_function_PeOy = await _Help_object_GHGa.commandUsage(_cmd_object_uiAZ)
		const _options_function_gxJb = () => { };
		const __hasHelpOption_boolean_hnAT = true;
		const __helpShortFlag_numeric_gIVz = 1.1103484011519384;
		const __findOption_function_XlUP = () => { };
		const __helpLongFlag_string_IyLS = "CRwAOrj0UfUZmnMPNTOhiMRqNPttx9MDeKSjKTXXgLET8opDQIw4";
		const _createOption_function_ucqm = () => { };
		const __helpDescription_string_dCPQ = "zqTEDW4vuq506ZutNoFghQoFrgDhHDji7Gg44daHJJlxrNGC6i22O1hbnfuTQWdTBdDmMc8WNmib8LhmzWBnYdIKavsa2lJXqCr";
		const __helpFlags_numeric_cvKE = -7.604418986099583;
		const _cmd_object_Psjv = {
			"options": _options_function_gxJb,
		"_hasHelpOption": __hasHelpOption_boolean_hnAT,
		"_helpShortFlag": __helpShortFlag_numeric_gIVz,
		"_findOption": __findOption_function_XlUP,
		"_helpLongFlag": __helpLongFlag_string_IyLS,
		"createOption": _createOption_function_ucqm,
		"_helpDescription": __helpDescription_string_dCPQ,
		"_helpFlags": __helpFlags_numeric_cvKE
	}
		const _visibleOptions_function_pxBq = await _Help_object_GHGa.visibleOptions(_cmd_object_Psjv)
		const _cmd_boolean_hAAa = true;
		const _visibleCommands_function_FsTr = () => { };
		const _subcommandTerm_function_NTeK = () => { };
		const _helper_object_priu = {
			"visibleCommands": _visibleCommands_function_FsTr,
		"subcommandTerm": _subcommandTerm_function_NTeK
	}
		const _longestSubcommandTermLength_function_KYtf = await _Help_object_GHGa.longestSubcommandTermLength(_cmd_boolean_hAAa, _helper_object_priu)


	});

	it('test for help', async () => {

		const _Help_object_fRJg = new Help()
		const _cmd_null_MOfc = null;
		const _subcommandTerm_function_yJdv = await _Help_object_fRJg.subcommandTerm(_cmd_null_MOfc)
		const _cmd_boolean_LTLC = false;
		const _helper_numeric_bTGw = -5.077320470757114;
		const _formatHelp_function_yXov = await _Help_object_fRJg.formatHelp(_cmd_boolean_LTLC, _helper_numeric_bTGw)


	});

	it('test for help', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:387:34:::392:5:::11723:11898
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:388:6:::390:7:::11744:11829
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/help.js:391:39:::391:41:::11869:11871
		const _Help_object_MjMs = new Help()
		const _flags_function_yaSh = () => { };
		const _option_object_PYNg = {
			"flags": _flags_function_yaSh
	}
		const _optionTerm_function_Bnpc = await _Help_object_MjMs.optionTerm(_option_object_PYNg)
		const _str_string_ENga = "uzuLBeWb3V5NlAoa3LF5vY9k8n";
		const _width_numeric_RYFv = 1.5434530973061378;
		const _indent_numeric_Ftqy = 7.0150484043899795;
		const _Assignment_numeric_fsVl = -8.59453139636182;
		const _wrap_function_ZTSE = await _Help_object_MjMs.wrap(_str_string_ENga, _width_numeric_RYFv, _indent_numeric_Ftqy, _Assignment_numeric_fsVl)
		const _cmd_null_IKrU = null;
		const _visibleArguments_function_efEr = () => { };
		const _argumentTerm_function_doBG = () => { };
		const _helper_object_Twky = {
			"visibleArguments": _visibleArguments_function_efEr,
		"argumentTerm": _argumentTerm_function_doBG
	}
		const _longestArgumentTermLength_function_gZeW = await _Help_object_MjMs.longestArgumentTermLength(_cmd_null_IKrU, _helper_object_Twky)
		const _cmd_boolean_zuQm = true;
		const _padWidth_function_fULV = () => { };
		const _helpWidth_boolean_QFsr = true;
		const _wrap_function_sbRe = () => { };
		const _commandUsage_function_RgIp = () => { };
		const _commandDescription_undefined_SNGW = undefined;
		const _visibleArguments_function_VNGz = () => { };
		const _argumentTerm_function_gJKQ = () => { };
		const _argumentDescription_function_DSjp = () => { };
		const _visibleOptions_function_PEjJ = () => { };
		const _optionTerm_function_NtqG = () => { };
		const _optionDescription_function_znsR = () => { };
		const _visibleCommands_function_MKet = () => { };
		const _subcommandTerm_function_sNIL = () => { };
		const _subcommandDescription_function_tnud = () => { };
		const _helper_object_ymZZ = {
			"padWidth": _padWidth_function_fULV,
		"helpWidth": _helpWidth_boolean_QFsr,
		"wrap": _wrap_function_sbRe,
		"commandUsage": _commandUsage_function_RgIp,
		"commandDescription": _commandDescription_undefined_SNGW,
		"visibleArguments": _visibleArguments_function_VNGz,
		"argumentTerm": _argumentTerm_function_gJKQ,
		"argumentDescription": _argumentDescription_function_DSjp,
		"visibleOptions": _visibleOptions_function_PEjJ,
		"optionTerm": _optionTerm_function_NtqG,
		"optionDescription": _optionDescription_function_znsR,
		"visibleCommands": _visibleCommands_function_MKet,
		"subcommandTerm": _subcommandTerm_function_sNIL,
		"subcommandDescription": _subcommandDescription_function_tnud
	}
		const _formatHelp_function_Kzyk = await _Help_object_MjMs.formatHelp(_cmd_boolean_zuQm, _helper_object_ymZZ)
		const _anon_string_aVSG = "v";
		const _argChoices_array_dKHv = [_anon_string_aVSG]
		const _negate_boolean_QVLC = false;
		const _defaultValue_null_dNKD = null;
		const _defaultValueDescription_boolean_iskL = true;
		const _envVar_null_bBEj = null;
		const _description_string_nfIB = "WLQE4GW5uXoxemickaaDDHQtppwDr9XktEB6648cBL0FOtaEbTwAsj6qVjcQTv8ubH3BykIoVx6gnEyJ8EuATiOG7o";
		const _option_object_vjNj = {
			"argChoices": _argChoices_array_dKHv,
		"negate": _negate_boolean_QVLC,
		"defaultValue": _defaultValue_null_dNKD,
		"defaultValueDescription": _defaultValueDescription_boolean_iskL,
		"envVar": _envVar_null_bBEj,
		"description": _description_string_nfIB
	}
		const _optionDescription_function_oOAp = await _Help_object_MjMs.optionDescription(_option_object_vjNj)


	});

	it('test for help', async () => {

		const _Help_object_DeYl = new Help()
		const _anon_string_NeTx = "ChQGmcUFkjH2A8BHASccD3kp2ZkEs9QEkVyKLbdleZACHcCf99AIIlVfeaE84KJfAyhGaYBeKz";
		const _cmd_array_nvmo = [_anon_string_NeTx]
		const _longestOptionTermLength_function_JHOA = () => { };
		const _longestSubcommandTermLength_function_ZoAa = () => { };
		const _longestArgumentTermLength_null_jDOf = null;
		const _helper_object_viBj = {
			"longestOptionTermLength": _longestOptionTermLength_function_JHOA,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_ZoAa,
		"longestArgumentTermLength": _longestArgumentTermLength_null_jDOf
	}
		const _padWidth_function_fujO = await _Help_object_DeYl.padWidth(_cmd_array_nvmo, _helper_object_viBj)
		const __args_string_JDbH = "TfTDSWTxlZl1LDFv2V";
		const __name_numeric_yuUk = -8.021161486446468;
		const _anon_string_txHA = "iRfBPPF";
		const __aliases_array_jmVu = [_anon_string_txHA]
		const _length_boolean_Cnwf = false;
		const _options_object_IvGb = {
			"length": _length_boolean_Cnwf
	}
		const _cmd_object_nblr = {
			"_args": __args_string_JDbH,
		"_name": __name_numeric_yuUk,
		"_aliases": __aliases_array_jmVu,
		"options": _options_object_IvGb
	}
		const _subcommandTerm_function_FJAm = await _Help_object_DeYl.subcommandTerm(_cmd_object_nblr)
		const _cmd_numeric_tdgT = 0.12715184660528855;
		const _visibleCommands_function_dDsB = await _Help_object_DeYl.visibleCommands(_cmd_numeric_tdgT)
		const _description_function_eQtc = () => { };
		const _cmd_object_LtSY = {
			"description": _description_function_eQtc
	}
		const _subcommandDescription_function_TMad = await _Help_object_DeYl.subcommandDescription(_cmd_object_LtSY)


	});

	it('test for help', async () => {

		const _Help_object_SQqH = new Help()
		const _flags_string_coRv = "ru";
		const _option_object_JCzs = {
			"flags": _flags_string_coRv
	}
		const _optionTerm_function_aYOI = await _Help_object_SQqH.optionTerm(_option_object_JCzs)
		const _anon_string_rFVb = "1ks3Ote6A1ji7csUTs2Y2RT8sYyoeKUDJhWmihbUbj7nxaz3QlPVkh3JHGcDtWJq4hG2QwhUa80";
		const _cmd_array_BJUj = [_anon_string_rFVb]
		const _longestOptionTermLength_function_jHYL = () => { };
		const _longestSubcommandTermLength_boolean_CiPw = false;
		const _longestArgumentTermLength_function_rMOP = () => { };
		const _helper_object_aFMn = {
			"longestOptionTermLength": _longestOptionTermLength_function_jHYL,
		"longestSubcommandTermLength": _longestSubcommandTermLength_boolean_CiPw,
		"longestArgumentTermLength": _longestArgumentTermLength_function_rMOP
	}
		const _padWidth_function_lxja = await _Help_object_SQqH.padWidth(_cmd_array_BJUj, _helper_object_aFMn)
		const _description_function_moyc = () => { };
		const _cmd_object_zvKh = {
			"description": _description_function_moyc
	}
		const _commandDescription_function_Guum = await _Help_object_SQqH.commandDescription(_cmd_object_zvKh)
		const _anon_string_AoGM = "Jvjv47cG2hkZaut4BOcJv6RBo2hFxoD3B2kphcwE4fiShRWTr943daHLhwyGhbwMi";
		const _commands_array_szaW = [_anon_string_AoGM]
		const __hasImplicitHelpCommand_function_oEdc = () => { };
		const __helpCommandnameAndArgs_string_jkYJ = "AAN";
		const _createCommand_function_aAhp = () => { };
		const _anon_string_Teqx = "Oq5ktWCbg9yQmYHKKxTyooBkk3o5X3hk7PjSmgHYeVrwbUOxzpjb9yPGYZinHcOowPMpaQoD1l";
		const __helpCommandDescription_array_BIei = [_anon_string_Teqx]
		const _cmd_object_gfhX = {
			"commands": _commands_array_szaW,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_function_oEdc,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_string_jkYJ,
		"createCommand": _createCommand_function_aAhp,
		"_helpCommandDescription": __helpCommandDescription_array_BIei
	}
		const _visibleCommands_function_lhxO = await _Help_object_SQqH.visibleCommands(_cmd_object_gfhX)


	});

	it('test for help', async () => {

		const _Help_object_hzhy = new Help()
		const _description_function_amtw = () => { };
		const _cmd_object_lrSC = {
			"description": _description_function_amtw
	}
		const _subcommandDescription_function_gqEi = await _Help_object_hzhy.subcommandDescription(_cmd_object_lrSC)
		const _cmd_boolean_OuLF = true;
		const _commandUsage_function_Uxmv = await _Help_object_hzhy.commandUsage(_cmd_boolean_OuLF)
		const _cmd_null_IDlL = null;
		const _visibleArguments_function_azCO = () => { };
		const _argumentTerm_function_TXDB = () => { };
		const _helper_object_OtFB = {
			"visibleArguments": _visibleArguments_function_azCO,
		"argumentTerm": _argumentTerm_function_TXDB
	}
		const _longestArgumentTermLength_function_zNRB = await _Help_object_hzhy.longestArgumentTermLength(_cmd_null_IDlL, _helper_object_OtFB)
		const _options_function_bTXs = () => { };
		const __hasHelpOption_boolean_fPBz = true;
		const __helpShortFlag_undefined_JdFQ = undefined;
		const __findOption_function_lDNj = () => { };
		const __helpLongFlag_null_PdZy = null;
		const _createOption_function_eqFs = () => { };
		const __helpDescription_object_jDdS = {
		
	}
		const __helpFlags_string_lnCb = "G8R5PpB5Ww3Fo5FibkLNYYc9RNfro9BB3oB1bzb84oJsctnKhJbo23tcPC";
		const _cmd_object_ayYh = {
			"options": _options_function_bTXs,
		"_hasHelpOption": __hasHelpOption_boolean_fPBz,
		"_helpShortFlag": __helpShortFlag_undefined_JdFQ,
		"_findOption": __findOption_function_lDNj,
		"_helpLongFlag": __helpLongFlag_null_PdZy,
		"createOption": _createOption_function_eqFs,
		"_helpDescription": __helpDescription_object_jDdS,
		"_helpFlags": __helpFlags_string_lnCb
	}
		const _visibleOptions_function_okxz = await _Help_object_hzhy.visibleOptions(_cmd_object_ayYh)


	});

	it('test for help', async () => {

		const _Help_object_HfMZ = new Help()
		const _anon_string_trSD = "sGL5yZwSiGUsVKkGEUvDTiGVP8cwrwmKL7sDvTfbVi";
		const _options_array_PfAR = [_anon_string_trSD]
		const __hasHelpOption_boolean_HEZq = false;
		const __helpShortFlag_object_uOAX = {
		
	}
		const __findOption_object_sliN = {
		
	}
		const __helpLongFlag_object_eDYh = {
		
	}
		const _createOption_function_DayH = () => { };
		const __helpDescription_string_mXBH = "htubsAly4Bk9S2jBXwGlcAXPnFxtvQ6GDE2HSdfM51jFrGmjdeb38";
		const __helpFlags_string_CowX = "pgee41tsJe6KgtlqyUnAHT0tdTjjySC8usSvnj3USlIetFgkqpLzT";
		const _cmd_object_zVBu = {
			"options": _options_array_PfAR,
		"_hasHelpOption": __hasHelpOption_boolean_HEZq,
		"_helpShortFlag": __helpShortFlag_object_uOAX,
		"_findOption": __findOption_object_sliN,
		"_helpLongFlag": __helpLongFlag_object_eDYh,
		"createOption": _createOption_function_DayH,
		"_helpDescription": __helpDescription_string_mXBH,
		"_helpFlags": __helpFlags_string_CowX
	}
		const _visibleOptions_function_pKTT = await _Help_object_HfMZ.visibleOptions(_cmd_object_zVBu)
		const _cmd_null_GtZb = null;
		const _commandDescription_function_QeqA = await _Help_object_HfMZ.commandDescription(_cmd_null_GtZb)
		const _cmd_string_dyID = "diaduT6tzHmUUsyKs0myxgVRTz3vbEFnJjKfBnIxC73jtsBeilrJnlqjMXdT6jtrRYogAEWk5UfqEOzvzV";
		const _longestOptionTermLength_function_LJwa = () => { };
		const _longestSubcommandTermLength_function_qVpv = () => { };
		const _longestArgumentTermLength_function_rjPV = () => { };
		const _helper_object_nKKF = {
			"longestOptionTermLength": _longestOptionTermLength_function_LJwa,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_qVpv,
		"longestArgumentTermLength": _longestArgumentTermLength_function_rjPV
	}
		const _padWidth_function_Ocgh = await _Help_object_HfMZ.padWidth(_cmd_string_dyID, _helper_object_nKKF)


	});

	it('test for help', async () => {

		const _Help_object_Pewy = new Help()
		const _cmd_boolean_EfWD = false;
		const _padWidth_function_wcNq = () => { };
		const _helpWidth_numeric_dGmy = 4.4538585183238375;
		const _wrap_function_NWYU = () => { };
		const _commandUsage_function_DpZG = () => { };
		const _commandDescription_boolean_YkRU = true;
		const _visibleArguments_boolean_whcq = true;
		const _argumentTerm_function_cmWU = () => { };
		const _argumentDescription_function_XjUl = () => { };
		const _visibleOptions_function_NaBL = () => { };
		const _optionTerm_function_BhOU = () => { };
		const _optionDescription_function_pIPs = () => { };
		const _visibleCommands_function_NvHI = () => { };
		const _subcommandTerm_function_Npwe = () => { };
		const _subcommandDescription_function_juNs = () => { };
		const _helper_object_SAJs = {
			"padWidth": _padWidth_function_wcNq,
		"helpWidth": _helpWidth_numeric_dGmy,
		"wrap": _wrap_function_NWYU,
		"commandUsage": _commandUsage_function_DpZG,
		"commandDescription": _commandDescription_boolean_YkRU,
		"visibleArguments": _visibleArguments_boolean_whcq,
		"argumentTerm": _argumentTerm_function_cmWU,
		"argumentDescription": _argumentDescription_function_XjUl,
		"visibleOptions": _visibleOptions_function_NaBL,
		"optionTerm": _optionTerm_function_BhOU,
		"optionDescription": _optionDescription_function_pIPs,
		"visibleCommands": _visibleCommands_function_NvHI,
		"subcommandTerm": _subcommandTerm_function_Npwe,
		"subcommandDescription": _subcommandDescription_function_juNs
	}
		const _formatHelp_function_mQrb = await _Help_object_Pewy.formatHelp(_cmd_boolean_EfWD, _helper_object_SAJs)
		const _flags_object_mbEa = {
		
	}
		const _option_object_LjWW = {
			"flags": _flags_object_mbEa
	}
		const _optionTerm_function_FPBc = await _Help_object_Pewy.optionTerm(_option_object_LjWW)
		const _anon_string_fPPe = "QzMK8XuaHIulbvaOUzZ5laxMRDfRb3CNO15skxcNUynmehSl3iOf2n9nv1v8VBMPIH0S9O8OjJrqUtTKpF";
		const _argChoices_array_Bmpz = [_anon_string_fPPe]
		const _negate_object_scKE = {
		
	}
		const _defaultValue_numeric_emCF = -4.520599198678551;
		const _defaultValueDescription_boolean_yIor = true;
		const _envVar_object_IdaJ = {
		
	}
		const _description_string_rnyE = "mJDwo2Z8y2Y3BidyRkuuGiYo3A9QagULaFkDa4ydOjb8U4UGUkUxdQgySoIe";
		const _option_object_zLyy = {
			"argChoices": _argChoices_array_Bmpz,
		"negate": _negate_object_scKE,
		"defaultValue": _defaultValue_numeric_emCF,
		"defaultValueDescription": _defaultValueDescription_boolean_yIor,
		"envVar": _envVar_object_IdaJ,
		"description": _description_string_rnyE
	}
		const _optionDescription_function_GstB = await _Help_object_Pewy.optionDescription(_option_object_zLyy)


	});

	it('test for help', async () => {

		const _Help_object_hFac = new Help()
		const _option_null_tGre = null;
		const _optionTerm_function_aOdo = await _Help_object_hFac.optionTerm(_option_null_tGre)
		const _anon_string_eGTr = "TUcujAxKh3";
		const _argChoices_array_YkTW = [_anon_string_eGTr]
		const _defaultValue_function_jbVJ = () => { };
		const _defaultValueDescription_boolean_pcCi = false;
		const _description_string_HICQ = "sSO0y9cUUhaf9jAoR5hbJEODNKhDCR6mAVynITjqJ";
		const _argument_object_pzag = {
			"argChoices": _argChoices_array_YkTW,
		"defaultValue": _defaultValue_function_jbVJ,
		"defaultValueDescription": _defaultValueDescription_boolean_pcCi,
		"description": _description_string_HICQ
	}
		const _argumentDescription_function_VtvD = await _Help_object_hFac.argumentDescription(_argument_object_pzag)
		const _cmd_string_BXCU = "pEXkv5cXOyprwGWaGFa7OlYFulAfJwtUjqBklEhKoARWX5VAgrIcWcmhCptlNgax3oIml84";
		const _visibleArguments_function_RmKZ = () => { };
		const _argumentTerm_function_fPcT = () => { };
		const _helper_object_TFUW = {
			"visibleArguments": _visibleArguments_function_RmKZ,
		"argumentTerm": _argumentTerm_function_fPcT
	}
		const _longestArgumentTermLength_function_UNcc = await _Help_object_hFac.longestArgumentTermLength(_cmd_string_BXCU, _helper_object_TFUW)


	});

	it('test for help', async () => {

		const _Help_object_uEZF = new Help()
		const _options_null_dCeC = null;
		const __hasHelpOption_boolean_fDZl = false;
		const __helpShortFlag_undefined_csTU = undefined;
		const __findOption_function_Gzad = () => { };
		const __helpLongFlag_string_mzpP = "Lbf8EcOY9p5rbUhg9z5M1WtcrWJvt9smTXL6pJWQd4HGXfK2wQGYhVt1Uw4CCA2EXhTwLswMI0r";
		const _createOption_function_LnOg = () => { };
		const __helpDescription_object_gYkI = {
		
	}
		const __helpFlags_undefined_mHUo = undefined;
		const _cmd_object_ofQr = {
			"options": _options_null_dCeC,
		"_hasHelpOption": __hasHelpOption_boolean_fDZl,
		"_helpShortFlag": __helpShortFlag_undefined_csTU,
		"_findOption": __findOption_function_Gzad,
		"_helpLongFlag": __helpLongFlag_string_mzpP,
		"createOption": _createOption_function_LnOg,
		"_helpDescription": __helpDescription_object_gYkI,
		"_helpFlags": __helpFlags_undefined_mHUo
	}
		const _visibleOptions_function_ZQjN = await _Help_object_uEZF.visibleOptions(_cmd_object_ofQr)
		const _cmd_function_SVfM = () => { };
		const _visibleCommands_function_BtGj = () => { };
		const _subcommandTerm_null_rvQg = null;
		const _helper_object_TmQM = {
			"visibleCommands": _visibleCommands_function_BtGj,
		"subcommandTerm": _subcommandTerm_null_rvQg
	}
		const _longestSubcommandTermLength_function_ovZm = await _Help_object_uEZF.longestSubcommandTermLength(_cmd_function_SVfM, _helper_object_TmQM)


	});

	it('test for help', async () => {

		const _Help_object_kKku = new Help()
		const _anon_string_XEbN = "BvvoAv6dCFc8JduatY9WljVaKwWNeYL3jvvlwP1zBzpQnEG";
		const _options_array_PNdc = [_anon_string_XEbN]
		const __hasHelpOption_boolean_jHNV = true;
		const __helpShortFlag_function_wyus = () => { };
		const __findOption_function_AIqJ = () => { };
		const __helpLongFlag_string_IsFW = "TLSjw5w9Lt6AEnxUTNkPXPaI8p3xH5et2Qb8n66v";
		const _createOption_function_Cawi = () => { };
		const __helpDescription_null_VaPD = null;
		const __helpFlags_function_PHHN = () => { };
		const _cmd_object_XwLr = {
			"options": _options_array_PNdc,
		"_hasHelpOption": __hasHelpOption_boolean_jHNV,
		"_helpShortFlag": __helpShortFlag_function_wyus,
		"_findOption": __findOption_function_AIqJ,
		"_helpLongFlag": __helpLongFlag_string_IsFW,
		"createOption": _createOption_function_Cawi,
		"_helpDescription": __helpDescription_null_VaPD,
		"_helpFlags": __helpFlags_function_PHHN
	}
		const _visibleOptions_function_njRC = await _Help_object_kKku.visibleOptions(_cmd_object_XwLr)
		const _str_null_oVvp = null;
		const _width_numeric_IsTW = -7.5755071869083075;
		const _indent_numeric_vWmO = -9.224212142944777;
		const _Assignment_null_JsuO = null;
		const _wrap_function_erdO = await _Help_object_kKku.wrap(_str_null_oVvp, _width_numeric_IsTW, _indent_numeric_vWmO, _Assignment_null_JsuO)
		const _anon_string_NSWU = "3hlPRqs5Lq0uDKXf3xO64SNIcolE4xBJuU9m09nRcWiEJU";
		const _commands_array_UzgH = [_anon_string_NSWU]
		const __hasImplicitHelpCommand_function_rVMk = () => { };
		const _match_function_EReH = () => { };
		const __helpCommandnameAndArgs_object_GsLR = {
			"match": _match_function_EReH
	}
		const _createCommand_function_cBIl = () => { };
		const __helpCommandDescription_numeric_VqKt = -5.812315198865551;
		const _cmd_object_lnUt = {
			"commands": _commands_array_UzgH,
		"_hasImplicitHelpCommand": __hasImplicitHelpCommand_function_rVMk,
		"_helpCommandnameAndArgs": __helpCommandnameAndArgs_object_GsLR,
		"createCommand": _createCommand_function_cBIl,
		"_helpCommandDescription": __helpCommandDescription_numeric_VqKt
	}
		const _visibleCommands_function_knHC = await _Help_object_kKku.visibleCommands(_cmd_object_lnUt)
		const _cmd_null_KAGb = null;
		const _visibleOptions_function_ZlUi = await _Help_object_kKku.visibleOptions(_cmd_null_KAGb)


	});

	it('test for help', async () => {

		const _Help_object_ymyt = new Help()
		const _cmd_function_ocsz = () => { };
		const _helper_null_LgvO = null;
		const _longestOptionTermLength_function_HRJz = await _Help_object_ymyt.longestOptionTermLength(_cmd_function_ocsz, _helper_null_LgvO)


	});

	it('test for help', async () => {

		const _Help_object_LFFr = new Help()
		const _anon_string_tuVc = "UnGaG2aV9k6";
		const _options_array_ybgr = [_anon_string_tuVc]
		const __hasHelpOption_boolean_sMmQ = true;
		const __helpShortFlag_numeric_qgET = 8.54152986971852;
		const __findOption_function_Zpxe = () => { };
		const __helpLongFlag_undefined_pmYg = undefined;
		const _createOption_function_bIbH = () => { };
		const __helpDescription_string_yjiu = "hVNpE3FhqWV9br2qNTJUGWJGDIM7zFEXmw264BVTQ3lKnkjSuxSdN4I1SbHYxIMXLPMnDUREIYFKWPww5RtWlqUxHBmdjnxu";
		const __helpFlags_object_Jckt = {
		
	}
		const _cmd_object_WzYo = {
			"options": _options_array_ybgr,
		"_hasHelpOption": __hasHelpOption_boolean_sMmQ,
		"_helpShortFlag": __helpShortFlag_numeric_qgET,
		"_findOption": __findOption_function_Zpxe,
		"_helpLongFlag": __helpLongFlag_undefined_pmYg,
		"createOption": _createOption_function_bIbH,
		"_helpDescription": __helpDescription_string_yjiu,
		"_helpFlags": __helpFlags_object_Jckt
	}
		const _visibleOptions_function_HxJZ = await _Help_object_LFFr.visibleOptions(_cmd_object_WzYo)
		const _cmd_undefined_sFgo = undefined;
		const _visibleOptions_function_OkSF = await _Help_object_LFFr.visibleOptions(_cmd_undefined_sFgo)
		const _anon_string_Vhtj = "bcmfcIQRUjHJufeELobYRI6XhiKfm7CbuVQUenOV6AQkLoVDylzUrJyVgu103RjM4sPugVB";
		const _argChoices_array_JhQn = [_anon_string_Vhtj]
		const _defaultValue_function_AWlo = () => { };
		const _defaultValueDescription_boolean_qpNk = true;
		const _description_string_jwog = "ePFlYyRg8yEKPFsg1TY2coBv58NQ2k9KDpaNl1vevTyhZi21QWzim1bXxu7u0ZHc";
		const _argument_object_Uohi = {
			"argChoices": _argChoices_array_JhQn,
		"defaultValue": _defaultValue_function_AWlo,
		"defaultValueDescription": _defaultValueDescription_boolean_qpNk,
		"description": _description_string_jwog
	}
		const _argumentDescription_function_Aicd = await _Help_object_LFFr.argumentDescription(_argument_object_Uohi)
		const _cmd_string_iEiY = "pj0sY1zUXUBxoqwIO9gTn8jFuKGuJH4ljyKdjvM0y4nB5YXe7f6WzVTZej5coZ3r7G31XXjvgSwmz";
		const _longestOptionTermLength_function_Onin = () => { };
		const _longestSubcommandTermLength_function_vVdg = () => { };
		const _longestArgumentTermLength_function_nVKv = () => { };
		const _helper_object_fERg = {
			"longestOptionTermLength": _longestOptionTermLength_function_Onin,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_vVdg,
		"longestArgumentTermLength": _longestArgumentTermLength_function_nVKv
	}
		const _padWidth_function_ywfd = await _Help_object_LFFr.padWidth(_cmd_string_iEiY, _helper_object_fERg)
		const _cmd_function_izOs = () => { };
		const _visibleOptions_function_WldE = () => { };
		const _optionTerm_function_USGA = () => { };
		const _helper_object_JbjL = {
			"visibleOptions": _visibleOptions_function_WldE,
		"optionTerm": _optionTerm_function_USGA
	}
		const _longestOptionTermLength_function_HxCQ = await _Help_object_LFFr.longestOptionTermLength(_cmd_function_izOs, _helper_object_JbjL)


	});

	it('test for help', async () => {

		const _Help_object_VZuO = new Help()
		const _cmd_boolean_uBVi = true;
		const _helper_undefined_UliW = undefined;
		const _formatHelp_function_lDQc = await _Help_object_VZuO.formatHelp(_cmd_boolean_uBVi, _helper_undefined_UliW)
		const _cmd_function_iAbs = () => { };
		const _visibleCommands_function_BoNz = () => { };
		const _subcommandTerm_function_bklR = () => { };
		const _helper_object_WVrr = {
			"visibleCommands": _visibleCommands_function_BoNz,
		"subcommandTerm": _subcommandTerm_function_bklR
	}
		const _longestSubcommandTermLength_function_WUoD = await _Help_object_VZuO.longestSubcommandTermLength(_cmd_function_iAbs, _helper_object_WVrr)


	});

	it('test for help', async () => {

		const _Help_object_Keqh = new Help()
		const _cmd_string_ILTX = "vhRw9E7RlZQ8zSzo5QPiuMUzLiVKE4AtMLrwn7vjJAvv1fcMvzuYNcsRsxYw2CE619r7jgfB53FF4trP8BKJeFSjloF";
		const _subcommandTerm_function_bdUj = await _Help_object_Keqh.subcommandTerm(_cmd_string_ILTX)
		const _cmd_string_Jwru = "vk0AcupSXXbS";
		const _longestOptionTermLength_function_sfDW = () => { };
		const _longestSubcommandTermLength_function_yMGL = () => { };
		const _longestArgumentTermLength_function_QFOR = () => { };
		const _helper_object_Odsk = {
			"longestOptionTermLength": _longestOptionTermLength_function_sfDW,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_yMGL,
		"longestArgumentTermLength": _longestArgumentTermLength_function_QFOR
	}
		const _padWidth_function_FjiA = await _Help_object_Keqh.padWidth(_cmd_string_Jwru, _helper_object_Odsk)


	});

	it('test for help', async () => {

		const _Help_object_FonC = new Help()
		const _anon_string_vdeM = "";
		const _options_array_EzhV = [_anon_string_vdeM]
		const __hasHelpOption_null_lFlH = null;
		const __helpShortFlag_undefined_JSGn = undefined;
		const __findOption_function_uhGf = () => { };
		const __helpLongFlag_string_zroZ = "uOwZEgqScAb2VB3d3Fe0z8NbEolj69OZyYiGeI34Fw6Qz";
		const _createOption_function_bJiY = () => { };
		const __helpDescription_boolean_HSak = true;
		const __helpFlags_object_Onrb = {
		
	}
		const _cmd_object_VYDf = {
			"options": _options_array_EzhV,
		"_hasHelpOption": __hasHelpOption_null_lFlH,
		"_helpShortFlag": __helpShortFlag_undefined_JSGn,
		"_findOption": __findOption_function_uhGf,
		"_helpLongFlag": __helpLongFlag_string_zroZ,
		"createOption": _createOption_function_bJiY,
		"_helpDescription": __helpDescription_boolean_HSak,
		"_helpFlags": __helpFlags_object_Onrb
	}
		const _visibleOptions_function_KKsP = await _Help_object_FonC.visibleOptions(_cmd_object_VYDf)
		const _cmd_function_EPpa = () => { };
		const _helper_null_oWFp = null;
		const _longestSubcommandTermLength_function_wiFU = await _Help_object_FonC.longestSubcommandTermLength(_cmd_function_EPpa, _helper_null_oWFp)
		const _anon_string_RPsg = "jH9fCUpDVYiy7EuPDOE7C1hSB5wXypskEYAsuzbA7ibTNK40x9hvJmbxWRudfvjRvfdvgO9s2P6KWlO9COc";
		const _options_array_VOFe = [_anon_string_RPsg]
		const __hasHelpOption_boolean_GKGZ = true;
		const __helpShortFlag_object_Yass = {
		
	}
		const __findOption_function_eKMb = () => { };
		const __helpLongFlag_boolean_TzfL = false;
		const _createOption_function_LIBD = () => { };
		const __helpDescription_numeric_nddf = 8.890332815287799;
		const __helpFlags_string_CvnK = "3Kt5GvxoQmCM99DiMTjh2z2NCz7PCUT5FyHYlczBNBhkDhNKDkI3mWKwa";
		const _cmd_object_lBFx = {
			"options": _options_array_VOFe,
		"_hasHelpOption": __hasHelpOption_boolean_GKGZ,
		"_helpShortFlag": __helpShortFlag_object_Yass,
		"_findOption": __findOption_function_eKMb,
		"_helpLongFlag": __helpLongFlag_boolean_TzfL,
		"createOption": _createOption_function_LIBD,
		"_helpDescription": __helpDescription_numeric_nddf,
		"_helpFlags": __helpFlags_string_CvnK
	}
		const _visibleOptions_function_Cdxh = await _Help_object_FonC.visibleOptions(_cmd_object_lBFx)


	});

	it('test for help', async () => {

		const _Help_object_zwfX = new Help()
		const _description_function_dlhh = () => { };
		const _cmd_object_PoPj = {
			"description": _description_function_dlhh
	}
		const _commandDescription_function_QBri = await _Help_object_zwfX.commandDescription(_cmd_object_PoPj)
		const _cmd_boolean_fent = true;
		const _helper_null_iKVq = null;
		const _formatHelp_function_VkGF = await _Help_object_zwfX.formatHelp(_cmd_boolean_fent, _helper_null_iKVq)
		const _cmd_string_SyKV = "ielNx2n0rlON8XYoX6PyS824U0CfMqDqfWHIx2IOHu";
		const _visibleArguments_string_IdzK = "4ALpNqWvwNKFXrnuX2jlvzXnclpJQn";
		const _argumentTerm_function_cjVk = () => { };
		const _helper_object_QTps = {
			"visibleArguments": _visibleArguments_string_IdzK,
		"argumentTerm": _argumentTerm_function_cjVk
	}
		const _longestArgumentTermLength_function_XaCj = await _Help_object_zwfX.longestArgumentTermLength(_cmd_string_SyKV, _helper_object_QTps)
		const _description_boolean_Plbn = false;
		const _cmd_object_IGjk = {
			"description": _description_boolean_Plbn
	}
		const _commandDescription_function_jcHk = await _Help_object_zwfX.commandDescription(_cmd_object_IGjk)
		const _cmd_boolean_kZjj = true;
		const _padWidth_function_XMCy = () => { };
		const _helpWidth_boolean_RkRU = false;
		const _wrap_function_NGgd = () => { };
		const _commandUsage_string_HrLh = "wq4OXHZ4SEoA4FOMStKSuQ7SUxFDBOKwHtxDCczkk5QFw4qdP1qQuUdUHpJw";
		const _commandDescription_function_HAEj = () => { };
		const _visibleArguments_function_ouWL = () => { };
		const _argumentTerm_null_cBmw = null;
		const _argumentDescription_function_QXSO = () => { };
		const _visibleOptions_function_FARP = () => { };
		const _optionTerm_function_gncS = () => { };
		const _optionDescription_function_miDQ = () => { };
		const _visibleCommands_function_Hdsh = () => { };
		const _subcommandTerm_function_npDL = () => { };
		const _subcommandDescription_function_wCbX = () => { };
		const _helper_object_VgRU = {
			"padWidth": _padWidth_function_XMCy,
		"helpWidth": _helpWidth_boolean_RkRU,
		"wrap": _wrap_function_NGgd,
		"commandUsage": _commandUsage_string_HrLh,
		"commandDescription": _commandDescription_function_HAEj,
		"visibleArguments": _visibleArguments_function_ouWL,
		"argumentTerm": _argumentTerm_null_cBmw,
		"argumentDescription": _argumentDescription_function_QXSO,
		"visibleOptions": _visibleOptions_function_FARP,
		"optionTerm": _optionTerm_function_gncS,
		"optionDescription": _optionDescription_function_miDQ,
		"visibleCommands": _visibleCommands_function_Hdsh,
		"subcommandTerm": _subcommandTerm_function_npDL,
		"subcommandDescription": _subcommandDescription_function_wCbX
	}
		const _formatHelp_function_xmmn = await _Help_object_zwfX.formatHelp(_cmd_boolean_kZjj, _helper_object_VgRU)


	});

	it('test for help', async () => {

		const _Help_object_YNPn = new Help()
		const _anon_string_RhYl = "9xDALGyGI6VRK33S8iH0m1IR5t3y2crAxKZSRSmGhjuN4";
		const _options_array_rOUe = [_anon_string_RhYl]
		const __hasHelpOption_boolean_CQWk = true;
		const __helpShortFlag_null_oKtz = null;
		const __findOption_function_CcQb = () => { };
		const __helpLongFlag_object_PjKt = {
		
	}
		const _createOption_string_vNIv = "4OYwireLkf7jjztIaWfu3SY5wSo8Hd";
		const __helpDescription_boolean_Isky = false;
		const __helpFlags_numeric_OgFc = 8.315760458800373;
		const _cmd_object_tzcp = {
			"options": _options_array_rOUe,
		"_hasHelpOption": __hasHelpOption_boolean_CQWk,
		"_helpShortFlag": __helpShortFlag_null_oKtz,
		"_findOption": __findOption_function_CcQb,
		"_helpLongFlag": __helpLongFlag_object_PjKt,
		"createOption": _createOption_string_vNIv,
		"_helpDescription": __helpDescription_boolean_Isky,
		"_helpFlags": __helpFlags_numeric_OgFc
	}
		const _visibleOptions_function_uYRG = await _Help_object_YNPn.visibleOptions(_cmd_object_tzcp)
		const _name_function_tUoR = () => { };
		const _argument_object_ecWc = {
			"name": _name_function_tUoR
	}
		const _argumentTerm_function_geYo = await _Help_object_YNPn.argumentTerm(_argument_object_ecWc)
		const _cmd_boolean_JmMF = false;
		const _padWidth_function_cPAx = () => { };
		const _helpWidth_boolean_htjJ = false;
		const _wrap_function_hwOa = () => { };
		const _commandUsage_function_mGFa = () => { };
		const _commandDescription_function_qPCv = () => { };
		const _visibleArguments_function_dUfJ = () => { };
		const _argumentTerm_function_gycv = () => { };
		const _argumentDescription_function_eeIV = () => { };
		const _visibleOptions_function_NZpB = () => { };
		const _optionTerm_function_LRvY = () => { };
		const _optionDescription_function_qqAe = () => { };
		const _visibleCommands_function_gPqG = () => { };
		const _subcommandTerm_function_oIzz = () => { };
		const _subcommandDescription_function_orWP = () => { };
		const _helper_object_oayB = {
			"padWidth": _padWidth_function_cPAx,
		"helpWidth": _helpWidth_boolean_htjJ,
		"wrap": _wrap_function_hwOa,
		"commandUsage": _commandUsage_function_mGFa,
		"commandDescription": _commandDescription_function_qPCv,
		"visibleArguments": _visibleArguments_function_dUfJ,
		"argumentTerm": _argumentTerm_function_gycv,
		"argumentDescription": _argumentDescription_function_eeIV,
		"visibleOptions": _visibleOptions_function_NZpB,
		"optionTerm": _optionTerm_function_LRvY,
		"optionDescription": _optionDescription_function_qqAe,
		"visibleCommands": _visibleCommands_function_gPqG,
		"subcommandTerm": _subcommandTerm_function_oIzz,
		"subcommandDescription": _subcommandDescription_function_orWP
	}
		const _formatHelp_function_wrdu = await _Help_object_YNPn.formatHelp(_cmd_boolean_JmMF, _helper_object_oayB)
		const __argsDescription_numeric_xwJT = -2.517969734451481;
		const __args_function_FhXA = () => { };
		const _cmd_object_LlNu = {
			"_argsDescription": __argsDescription_numeric_xwJT,
		"_args": __args_function_FhXA
	}
		const _visibleArguments_function_sJJj = await _Help_object_YNPn.visibleArguments(_cmd_object_LlNu)


	});

	it('test for help', async () => {

		const _Help_object_DVhu = new Help()
		const _anon_string_MNtx = "M1nxFNSEVGoFqEFg91Ehw3Amxhd0VNerMxMWfMan3fYyPDaF9EkXcaYhUx8CQmyYjOORY71VyH";
		const _options_array_bVQI = [_anon_string_MNtx]
		const __hasHelpOption_boolean_XsVK = false;
		const __helpShortFlag_boolean_zUpa = true;
		const __findOption_string_LxpT = "F5WUIjrMqQxoPh1kLoHAbT85vJV3UTcw2XREoxjI5DJcxOlxeL5SX";
		const __helpLongFlag_numeric_IKSu = -7.146805979410988;
		const _createOption_function_HKEB = () => { };
		const __helpDescription_function_AwjA = () => { };
		const __helpFlags_object_wcvI = {
		
	}
		const _cmd_object_rDMh = {
			"options": _options_array_bVQI,
		"_hasHelpOption": __hasHelpOption_boolean_XsVK,
		"_helpShortFlag": __helpShortFlag_boolean_zUpa,
		"_findOption": __findOption_string_LxpT,
		"_helpLongFlag": __helpLongFlag_numeric_IKSu,
		"createOption": _createOption_function_HKEB,
		"_helpDescription": __helpDescription_function_AwjA,
		"_helpFlags": __helpFlags_object_wcvI
	}
		const _visibleOptions_function_FTjv = await _Help_object_DVhu.visibleOptions(_cmd_object_rDMh)
		const _cmd_boolean_kSzL = true;
		const _padWidth_function_NQse = () => { };
		const _helpWidth_boolean_azKD = true;
		const _wrap_function_KWfT = () => { };
		const _commandUsage_undefined_criP = undefined;
		const _commandDescription_function_qjWq = () => { };
		const _visibleArguments_boolean_ABDk = true;
		const _argumentTerm_function_yQTc = () => { };
		const _argumentDescription_function_kYaj = () => { };
		const _visibleOptions_function_ZByZ = () => { };
		const _optionTerm_function_HBTW = () => { };
		const _optionDescription_function_Bqus = () => { };
		const _visibleCommands_function_FJME = () => { };
		const _subcommandTerm_function_FycV = () => { };
		const _subcommandDescription_function_vDwS = () => { };
		const _helper_object_GfVU = {
			"padWidth": _padWidth_function_NQse,
		"helpWidth": _helpWidth_boolean_azKD,
		"wrap": _wrap_function_KWfT,
		"commandUsage": _commandUsage_undefined_criP,
		"commandDescription": _commandDescription_function_qjWq,
		"visibleArguments": _visibleArguments_boolean_ABDk,
		"argumentTerm": _argumentTerm_function_yQTc,
		"argumentDescription": _argumentDescription_function_kYaj,
		"visibleOptions": _visibleOptions_function_ZByZ,
		"optionTerm": _optionTerm_function_HBTW,
		"optionDescription": _optionDescription_function_Bqus,
		"visibleCommands": _visibleCommands_function_FJME,
		"subcommandTerm": _subcommandTerm_function_FycV,
		"subcommandDescription": _subcommandDescription_function_vDwS
	}
		const _formatHelp_function_rOKF = await _Help_object_DVhu.formatHelp(_cmd_boolean_kSzL, _helper_object_GfVU)


	});

	it('test for help', async () => {

		const _Help_object_jgay = new Help()
		const _argChoices_string_tBmH = "NG";
		const _negate_undefined_XWtu = undefined;
		const _defaultValue_null_wJqN = null;
		const _defaultValueDescription_boolean_evPi = true;
		const _envVar_object_RPJm = {
		
	}
		const _description_string_Ceds = "8sADevyy6zI6pPhcMF6PKAvD8mhtKXGldEf1puMVKu2VonMpqyabWjV1PBMr5PG5sg4wJw";
		const _option_object_ANEn = {
			"argChoices": _argChoices_string_tBmH,
		"negate": _negate_undefined_XWtu,
		"defaultValue": _defaultValue_null_wJqN,
		"defaultValueDescription": _defaultValueDescription_boolean_evPi,
		"envVar": _envVar_object_RPJm,
		"description": _description_string_Ceds
	}
		const _optionDescription_function_XWgB = await _Help_object_jgay.optionDescription(_option_object_ANEn)
		const _description_numeric_Kddc = -6.900475856784878;
		const _cmd_object_GUdR = {
			"description": _description_numeric_Kddc
	}
		const _subcommandDescription_function_vFaV = await _Help_object_jgay.subcommandDescription(_cmd_object_GUdR)
		const _name_function_eHrI = () => { };
		const _argument_object_SdZM = {
			"name": _name_function_eHrI
	}
		const _argumentTerm_function_dJZo = await _Help_object_jgay.argumentTerm(_argument_object_SdZM)


	});

	it('test for help', async () => {

		const _Help_object_Duee = new Help()
		const _option_undefined_rHYU = undefined;
		const _optionDescription_function_uqBV = await _Help_object_Duee.optionDescription(_option_undefined_rHYU)
		const _cmd_function_LcjY = () => { };
		const _visibleCommands_function_vMZc = () => { };
		const _subcommandTerm_function_JoLJ = () => { };
		const _helper_object_nUAl = {
			"visibleCommands": _visibleCommands_function_vMZc,
		"subcommandTerm": _subcommandTerm_function_JoLJ
	}
		const _longestSubcommandTermLength_function_nqUo = await _Help_object_Duee.longestSubcommandTermLength(_cmd_function_LcjY, _helper_object_nUAl)
		const _cmd_null_eSKx = null;
		const _longestOptionTermLength_function_SizY = () => { };
		const _longestSubcommandTermLength_function_xyiH = () => { };
		const _longestArgumentTermLength_function_dpBo = () => { };
		const _helper_object_RPMa = {
			"longestOptionTermLength": _longestOptionTermLength_function_SizY,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_xyiH,
		"longestArgumentTermLength": _longestArgumentTermLength_function_dpBo
	}
		const _padWidth_function_fyWN = await _Help_object_Duee.padWidth(_cmd_null_eSKx, _helper_object_RPMa)


	});

	it('test for help', async () => {

		const _Help_object_rCqG = new Help()
		const _flags_function_xSDS = () => { };
		const _option_object_wQCx = {
			"flags": _flags_function_xSDS
	}
		const _optionTerm_function_FHJz = await _Help_object_rCqG.optionTerm(_option_object_wQCx)
		const _match_string_RzSP = "6VAIa4Zt7vFL3m57Bf738TzU8zgO3VVdueYIotTESrYCCwayoU999EtcGsG2qVLI55hD1BN4WuxmtcI8ZW1bJ";
		const _substr_boolean_UsoP = false;
		const _str_object_DYIJ = {
			"match": _match_string_RzSP,
		"substr": _substr_boolean_UsoP
	}
		const _width_numeric_eCsI = -0.363765522787622;
		const _indent_numeric_OMRt = -4.360211250616458;
		const _Assignment_numeric_QKVg = -4.987219989750171;
		const _wrap_function_cWMp = await _Help_object_rCqG.wrap(_str_object_DYIJ, _width_numeric_eCsI, _indent_numeric_OMRt, _Assignment_numeric_QKVg)


	});

	it('test for help', async () => {

		const _Help_object_WhvL = new Help()
		const _argument_numeric_SneY = -9.942281171915036;
		const _argumentDescription_function_Lupx = await _Help_object_WhvL.argumentDescription(_argument_numeric_SneY)
		const _anon_string_nmkK = "GRYi9KbLX7PniH8jpaEMqrnY";
		const _options_array_fVIN = [_anon_string_nmkK]
		const __hasHelpOption_boolean_kIYb = true;
		const __helpShortFlag_string_uTxj = "IL8DUbGllK4Ygh6qtiBVhNAA3Q9GtFJXuVzdUvRj5hUR";
		const __findOption_function_KHVY = () => { };
		const __helpLongFlag_function_oCVG = () => { };
		const _createOption_function_Dhzh = () => { };
		const __helpDescription_string_fWsX = "m4cp0pAJC";
		const __helpFlags_function_rcXY = () => { };
		const _cmd_object_iidy = {
			"options": _options_array_fVIN,
		"_hasHelpOption": __hasHelpOption_boolean_kIYb,
		"_helpShortFlag": __helpShortFlag_string_uTxj,
		"_findOption": __findOption_function_KHVY,
		"_helpLongFlag": __helpLongFlag_function_oCVG,
		"createOption": _createOption_function_Dhzh,
		"_helpDescription": __helpDescription_string_fWsX,
		"_helpFlags": __helpFlags_function_rcXY
	}
		const _visibleOptions_function_aoND = await _Help_object_WhvL.visibleOptions(_cmd_object_iidy)
		const _description_function_eTje = () => { };
		const _cmd_object_xGEb = {
			"description": _description_function_eTje
	}
		const _commandDescription_function_OGbR = await _Help_object_WhvL.commandDescription(_cmd_object_xGEb)
		const _cmd_null_KaRh = null;
		const _longestOptionTermLength_function_KitX = () => { };
		const _longestSubcommandTermLength_function_LNQv = () => { };
		const _longestArgumentTermLength_function_Egwv = () => { };
		const _helper_object_FWvv = {
			"longestOptionTermLength": _longestOptionTermLength_function_KitX,
		"longestSubcommandTermLength": _longestSubcommandTermLength_function_LNQv,
		"longestArgumentTermLength": _longestArgumentTermLength_function_Egwv
	}
		const _padWidth_function_vNeU = await _Help_object_WhvL.padWidth(_cmd_null_KaRh, _helper_object_FWvv)
		const _cmd_null_MkxL = null;
		const _visibleArguments_function_WZxe = await _Help_object_WhvL.visibleArguments(_cmd_null_MkxL)


	});

	it('test for help', async () => {

		const _Help_object_mEas = new Help()
		const _cmd_null_GCXe = null;
		const _visibleOptions_function_zjlY = await _Help_object_mEas.visibleOptions(_cmd_null_GCXe)
		const _anon_string_TzQo = "Oaa368q6uFpDVO4jxB3BbXt2LeGzt6m768tiXbihOXyD1fGG";
		const _argChoices_array_WHTU = [_anon_string_TzQo]
		const _negate_boolean_oXda = false;
		const _defaultValue_object_ZFAK = {
		
	}
		const _defaultValueDescription_string_jGoY = "JhHdQToom2N4yfLP2J3FHTz411ptiYxFAfUKGcx2BOsHxNj7GCP5NFZxdeLcD";
		const _envVar_undefined_tCEc = undefined;
		const _description_string_wFzv = "ywd";
		const _option_object_zHwe = {
			"argChoices": _argChoices_array_WHTU,
		"negate": _negate_boolean_oXda,
		"defaultValue": _defaultValue_object_ZFAK,
		"defaultValueDescription": _defaultValueDescription_string_jGoY,
		"envVar": _envVar_undefined_tCEc,
		"description": _description_string_wFzv
	}
		const _optionDescription_function_DNsB = await _Help_object_mEas.optionDescription(_option_object_zHwe)


	});

	it('test for help', async () => {

		const _Help_object_KfMa = new Help()
		const _cmd_null_LdCT = null;
		const _helper_undefined_LdLx = undefined;
		const _padWidth_function_xjFv = await _Help_object_KfMa.padWidth(_cmd_null_LdCT, _helper_undefined_LdLx)


	});

	it('test for help', async () => {

		const _Help_object_BeEo = new Help()
		const __args_null_vvAU = null;
		const __name_numeric_MQHK = 5.59552212832701;
		const _anon_string_cStn = "x";
		const __aliases_array_nXUw = [_anon_string_cStn]
		const _anon_string_Cekf = "8MarDKA1ojJapaLIXJ2QGHWMLQGjhZJLVmiN6ke7C5WinbPBKNmgvyuypeIIO2EjczGF7y1gpSQ2k";
		const _options_array_rmkg = [_anon_string_Cekf]
		const _cmd_object_eyor = {
			"_args": __args_null_vvAU,
		"_name": __name_numeric_MQHK,
		"_aliases": __aliases_array_nXUw,
		"options": _options_array_rmkg
	}
		const _subcommandTerm_function_JTRN = await _Help_object_BeEo.subcommandTerm(_cmd_object_eyor)
		const __name_string_gvUY = "qtezXdaaHxzQDl2cS7BPUc1rCn6k84ygMSpalp849hQ7vFnffzV4oWcpQeGoY0zmNTXb739R98Hcvcp";
		const _anon_string_qNzf = "DNgPfECP8m7Xbmm3bd4oxahFMpYjkBbJtUTXXV6LRaPJqBLLXYXreYHZfRZwTyGxzs1eREBprygqzN7ePEd";
		const __aliases_array_wefp = [_anon_string_qNzf]
		const _parent_function_ffhY = () => { };
		const _usage_function_cZft = () => { };
		const _cmd_object_nHnz = {
			"_name": __name_string_gvUY,
		"_aliases": __aliases_array_wefp,
		"parent": _parent_function_ffhY,
		"usage": _usage_function_cZft
	}
		const _commandUsage_function_EpyI = await _Help_object_BeEo.commandUsage(_cmd_object_nHnz)
		const __argsDescription_numeric_dRnZ = -6.228743211585794;
		const __args_function_hqca = () => { };
		const _cmd_object_jKrw = {
			"_argsDescription": __argsDescription_numeric_dRnZ,
		"_args": __args_function_hqca
	}
		const _visibleArguments_function_EeBu = await _Help_object_BeEo.visibleArguments(_cmd_object_jKrw)


	});

	it('test for help', async () => {

		const _Help_object_wLWI = new Help()
		const _flags_numeric_gmrw = 5.636028186006479;
		const _option_object_CJov = {
			"flags": _flags_numeric_gmrw
	}
		const _optionTerm_function_btSZ = await _Help_object_wLWI.optionTerm(_option_object_CJov)
		const _cmd_string_eZoB = "fC1w8fjr889v6OJSMozkrK84XmwkojfmA3AuJlLufKMBbYn5RX6JigFJqLtqMQMQkGEjEKel9Nih7JLtCbz";
		const _helper_undefined_eSVa = undefined;
		const _longestOptionTermLength_function_YSyf = await _Help_object_wLWI.longestOptionTermLength(_cmd_string_eZoB, _helper_undefined_eSVa)
		const _argument_function_tDGg = () => { };
		const _argumentTerm_function_nsGX = await _Help_object_wLWI.argumentTerm(_argument_function_tDGg)
		const _description_function_Zgzb = () => { };
		const _cmd_object_TRbx = {
			"description": _description_function_Zgzb
	}
		const _commandDescription_function_WkJZ = await _Help_object_wLWI.commandDescription(_cmd_object_TRbx)


	});

	it('test for help', async () => {

		const _Help_object_yYsO = new Help()
		const _argument_null_ZDWV = null;
		const _argumentDescription_function_EaSt = await _Help_object_yYsO.argumentDescription(_argument_null_ZDWV)


	});

	it('test for help', async () => {

		const _Help_object_ymXt = new Help()
		const _cmd_string_tQOK = "g89wuSK";
		const _helper_undefined_gmoh = undefined;
		const _longestSubcommandTermLength_function_QvjK = await _Help_object_ymXt.longestSubcommandTermLength(_cmd_string_tQOK, _helper_undefined_gmoh)


	});
})