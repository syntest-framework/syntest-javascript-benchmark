describe('suggestSimilar', () => {
	const {suggestSimilar} = require("../../benchmark/commanderjs/lib/suggestSimilar.js");

	it('test for suggestSimilar', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:55:0:::98:1:::1383:2720
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:56:2:::56:56:::1429:1483
		const _startsWith_function_szYR = () => { };
		const _slice_function_xIVD = () => { };
		const _length_boolean_lRbu = false;
		const _word_object_DfsV = {
			"startsWith": _startsWith_function_szYR,
		"slice": _slice_function_xIVD,
		"length": _length_boolean_lRbu
	}
		const _length_object_SLXD = {
		
	}
		const _map_function_oOAW = () => { };
		const _forEach_function_eToA = () => { };
		const _candidates_object_DqaP = {
			"length": _length_object_SLXD,
		"map": _map_function_oOAW,
		"forEach": _forEach_function_eToA
	}
		const _suggestSimilar_function_NORa = await suggestSimilar(_word_object_DfsV, _candidates_object_DqaP)


	});

	it('test for suggestSimilar', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:56:46:::56:56:::1473:1483
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:62:4:::62:25:::1645:1666
		const _startsWith_function_shEg = () => { };
		const _slice_function_ZtCy = () => { };
		const _length_null_ANsF = null;
		const _word_object_oCDp = {
			"startsWith": _startsWith_function_shEg,
		"slice": _slice_function_ZtCy,
		"length": _length_null_ANsF
	}
		const _candidates_function_MdxZ = () => { };
		const _suggestSimilar_function_ElLv = await suggestSimilar(_word_object_oCDp, _candidates_function_MdxZ)


	});

	it('test for suggestSimilar', async () => {

		const _anon_string_oaIL = "VGbI9tyKsVNpSa5mzCOOMgY3TOifGEfh7PmC6vGaCfpmh8ZmvW6ECtUOdusL";
		const _word_array_BwWS = [_anon_string_oaIL]
		const _candidates_string_UOhZ = "l5WAn1i62pidoMFdKzTlrVd";
		const _suggestSimilar_function_RhGT = await suggestSimilar(_word_array_BwWS, _candidates_string_UOhZ)


	});

	it('test for suggestSimilar', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:69:21:::84:3:::1842:2394
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:61:2:::64:3:::1617:1736
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:87:2:::89:3:::2446:2531
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:70:31:::70:38:::1890:1897
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:91:2:::93:3:::2535:2625
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:94:2:::96:3:::2628:2705
		const _startsWith_function_BdNd = () => { };
		const _slice_function_YcaZ = () => { };
		const _length_function_yehk = () => { };
		const _word_object_vImf = {
			"startsWith": _startsWith_function_BdNd,
		"slice": _slice_function_YcaZ,
		"length": _length_function_yehk
	}
		const _candidates_string_rBcQ = "4enXln55vRgLfRPMsAggsstEkhd8aYhNc6avSwp7GuVRA";
		const _suggestSimilar_function_XAZY = await suggestSimilar(_word_object_vImf, _candidates_string_rBcQ)


	});

	it('test for suggestSimilar', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:3:0:::45:1:::24:1233
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:70:4:::70:38:::1863:1897
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:9:2:::9:87:::284:369
		const _startsWith_function_VAgy = () => { };
		const _slice_function_rdKW = () => { };
		const _length_undefined_mGpE = undefined;
		const _word_object_Wybj = {
			"startsWith": _startsWith_function_VAgy,
		"slice": _slice_function_rdKW,
		"length": _length_undefined_mGpE
	}
		const _anon_string_eYev = "aIPxjDr6Vegyd9r4b12XElWMSkDn914W7JFxp3smG97n1SLmfWzmu2KierFLejTNXGcnvlhmv5";
		const _candidates_array_Ninw = [_anon_string_eYev]
		const _suggestSimilar_function_rsSw = await suggestSimilar(_word_object_Wybj, _candidates_array_Ninw)


	});

	it('test for suggestSimilar', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:9:51:::9:87:::333:369
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:75:4:::83:5:::2096:2390
		const _word_string_PSEm = "Xhtb6AVMa87CyVVsVOLmbzfJRBs7mvaxJhp6J3";
		const _anon_string_pnCD = "tn9IpAA51fOe6h9CIX4miDz6vILUUjft8";
		const _candidates_array_znGz = [_anon_string_pnCD]
		const _suggestSimilar_function_MeUV = await suggestSimilar(_word_string_PSEm, _candidates_array_znGz)


	});

	it('test for suggestSimilar', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:76:6:::82:7:::2136:2384
		const _word_string_GlNa = "VdTiI1n28jwuPdQofnzxRDwDBuf9jqHDIzvfuspSA1U8NUK7T119YbqyTTemI4kuo93oPEQwddEqzNCowG7hxHbdOOveNMrYBV";
		const _candidates_string_QPhC = "ADxGBFrJ7aWpkzv4tavmaIB";
		const _suggestSimilar_function_RFlO = await suggestSimilar(_word_string_GlNa, _candidates_string_QPhC)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_aItZ = "qjEP5BgnKxw06Su35vRu5khwqHAryQBxcpIMJwplfqLw9zLxltnxwrTtuXSz5";
		const _candidates_numeric_mopt = -8.41970213524067;
		const _suggestSimilar_function_DpDJ = await suggestSimilar(_word_string_aItZ, _candidates_numeric_mopt)


	});

	it('test for suggestSimilar', async () => {

		const _word_null_HfgC = null;
		const _anon_string_rXMp = "gGS8mJWSEF77Nn5jNpbjsQW1EoYlNfZ3JP4NHNvaH4SsVjirFT5EugCPO4zZNfeFE";
		const _candidates_array_bVYj = [_anon_string_rXMp]
		const _suggestSimilar_function_AtyL = await suggestSimilar(_word_null_HfgC, _candidates_array_bVYj)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_YKPS = "uDjFcBNvxVrDCOzNBncs1jEYBfBBS0HK5eD4TqEo1knnHiQF9";
		const _candidates_numeric_ckfD = 1.4807462868962062;
		const _suggestSimilar_function_PRhM = await suggestSimilar(_word_string_YKPS, _candidates_numeric_ckfD)


	});

	it('test for suggestSimilar', async () => {

		const _startsWith_function_oVNT = () => { };
		const _slice_function_ZJzj = () => { };
		const _length_null_XMZi = null;
		const _word_object_yfXl = {
			"startsWith": _startsWith_function_oVNT,
		"slice": _slice_function_ZJzj,
		"length": _length_null_XMZi
	}
		const _candidates_numeric_zUBW = 3.2192102198633563;
		const _suggestSimilar_function_hwdb = await suggestSimilar(_word_object_yfXl, _candidates_numeric_zUBW)


	});

	it('test for suggestSimilar', async () => {

		const _word_boolean_kNPv = false;
		const _candidates_boolean_Dahf = true;
		const _suggestSimilar_function_siOR = await suggestSimilar(_word_boolean_kNPv, _candidates_boolean_Dahf)


	});

	it('test for suggestSimilar', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/suggestSimilar.js:16:4:::16:15:::528:539
		const _word_string_RZWn = "rzHGl2l2Po2LWGCswqrABVG5usXgtpS2OdGRIfFgmnz1vOWdcWEU6DvgX7YDqkxfyDePtLouGkxsta";
		const _anon_string_cskM = "5xtAFtlp3QnUGgTYznaQbaKSbCu7ldRoJOOrjoVbTbOlmKdhe2w99N36XZZIGuDHAJli5qSm57bp6Nch";
		const _candidates_array_BEhw = [_anon_string_cskM]
		const _suggestSimilar_function_FfFg = await suggestSimilar(_word_string_RZWn, _candidates_array_BEhw)


	});

	it('test for suggestSimilar', async () => {

		const _word_numeric_Gnje = -5.143325060288569;
		const _candidates_numeric_kMJw = -5.1004040581808505;
		const _suggestSimilar_function_xTRU = await suggestSimilar(_word_numeric_Gnje, _candidates_numeric_kMJw)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_aCTm = "Nt9xQjHQKO7u1DnDr5xdjbO7prqfdFl9qu6sflD0e4LjMxujvUu72OKimgcpr";
		const _candidates_numeric_NGXO = -5.504329321574341;
		const _suggestSimilar_function_tHvA = await suggestSimilar(_word_string_aCTm, _candidates_numeric_NGXO)


	});

	it('test for suggestSimilar', async () => {

		const _anon_string_LLOC = "UnkyZT2Bkej5faWfaA6aZzQpszNES";
		const _word_array_onZU = [_anon_string_LLOC]
		const _candidates_numeric_paBU = 4.91156930502971;
		const _suggestSimilar_function_lcNM = await suggestSimilar(_word_array_onZU, _candidates_numeric_paBU)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_xfoz = "kpF8GezOYQWWGuMr7yObVTagqp9LcS922VWRzSHoXkFK6wghLuTObwBvLM4MpWUMqbnTa";
		const _candidates_numeric_Yjwo = 6.597351091832067;
		const _suggestSimilar_function_soii = await suggestSimilar(_word_string_xfoz, _candidates_numeric_Yjwo)


	});

	it('test for suggestSimilar', async () => {

		const _startsWith_function_TkkD = () => { };
		const _slice_function_JewC = () => { };
		const _length_string_mwVa = "Fm7R5pTX3kChwn6L1FtbDilvRuZntamiwXprJ4GH9p6rDTlY1qepAbuuBssrzDvbl81c8YFc9llNUj0yqVD0N";
		const _word_object_ZLhM = {
			"startsWith": _startsWith_function_TkkD,
		"slice": _slice_function_JewC,
		"length": _length_string_mwVa
	}
		const _candidates_numeric_aReV = -4.659615806202765;
		const _suggestSimilar_function_NDgZ = await suggestSimilar(_word_object_ZLhM, _candidates_numeric_aReV)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_OTup = "28xC6vgXTXwJmN4thu7yAyrbnYdOTQN1p9L4EGTGvuA8pCz5Qc5spQVkP66RTRCbWG0M2p2bt0x4MBDUXL";
		const _candidates_numeric_iOgi = -4.469416042211684;
		const _suggestSimilar_function_Tecm = await suggestSimilar(_word_string_OTup, _candidates_numeric_iOgi)


	});

	it('test for suggestSimilar', async () => {

		const _word_undefined_uLcW = undefined;
		const _anon_string_zcuT = "lYgqemDdtBVcvYyCPC1vtuQjMgOqcE7rehEY2gnsmw9MZaSeKqgXeoulyozm1w0TmOS";
		const _candidates_array_wIUs = [_anon_string_zcuT]
		const _suggestSimilar_function_IpBB = await suggestSimilar(_word_undefined_uLcW, _candidates_array_wIUs)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_AGNa = "3s9l9NXStPFRKra7gpUqFm0MrQcMZfpzAR612n4zCM9nTGz2aPRKf13lgWTNSJmLwHFFFVjWKkdurT8Pj4GwzqfAAp7gv7HLrc";
		const _candidates_numeric_hvsN = -6.8398279162930535;
		const _suggestSimilar_function_bUnN = await suggestSimilar(_word_string_AGNa, _candidates_numeric_hvsN)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_RSbM = "Kmxg";
		const _candidates_numeric_ndmE = -9.5949870728144;
		const _suggestSimilar_function_MyJz = await suggestSimilar(_word_string_RSbM, _candidates_numeric_ndmE)


	});

	it('test for suggestSimilar', async () => {

		const _startsWith_function_FpCo = () => { };
		const _slice_function_bsUd = () => { };
		const _length_boolean_UXle = false;
		const _word_object_ZVZY = {
			"startsWith": _startsWith_function_FpCo,
		"slice": _slice_function_bsUd,
		"length": _length_boolean_UXle
	}
		const _candidates_numeric_UQlf = 0.7395776793990763;
		const _suggestSimilar_function_VqMo = await suggestSimilar(_word_object_ZVZY, _candidates_numeric_UQlf)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_wRUX = "o73yyOd";
		const _candidates_numeric_vtOC = 5.479747730367732;
		const _suggestSimilar_function_XzNO = await suggestSimilar(_word_string_wRUX, _candidates_numeric_vtOC)


	});

	it('test for suggestSimilar', async () => {

		const _startsWith_function_HWzr = () => { };
		const _slice_function_xQyx = () => { };
		const _length_object_CMyg = {
		
	}
		const _word_object_wHnB = {
			"startsWith": _startsWith_function_HWzr,
		"slice": _slice_function_xQyx,
		"length": _length_object_CMyg
	}
		const _candidates_numeric_ZYFv = 8.517832755095998;
		const _suggestSimilar_function_JfwT = await suggestSimilar(_word_object_wHnB, _candidates_numeric_ZYFv)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_zveJ = "EZ84lGjqNBWaeOjXkCAnWzv";
		const _candidates_numeric_ROVm = -1.0819804928051227;
		const _suggestSimilar_function_qmXP = await suggestSimilar(_word_string_zveJ, _candidates_numeric_ROVm)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_Nbkn = "gsOvTpwlSxfRrrSUurdtYV9Ak4A57skOqNhEHj0uYo9p9DKSWekpD3asFRY4HpgFIS3tjYccbvRnD";
		const _candidates_numeric_DuwB = -7.032317874724852;
		const _suggestSimilar_function_zqVt = await suggestSimilar(_word_string_Nbkn, _candidates_numeric_DuwB)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_Ropn = "lsD32mMnHMKr6QXdg1yypddJY38uTY6BvAx5NJIGYZYcsEKcWp69oz7hjKTlbpO0gNf13LQ2pocCQ2N0c9I7RBTrC";
		const _candidates_numeric_DKUe = 0.5145030069964189;
		const _suggestSimilar_function_rbHL = await suggestSimilar(_word_string_Ropn, _candidates_numeric_DKUe)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_NtOb = "d27B6Ci8rvnVdNyeA23F4LUcKk45";
		const _candidates_numeric_kYXF = -2.0692980495530167;
		const _suggestSimilar_function_SGJY = await suggestSimilar(_word_string_NtOb, _candidates_numeric_kYXF)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_dLAW = "jBAivXCNJ4OtEvnjxBp7yJQ7HnXK3wx2a2eZ7K4xzAGzSjf7lwsSIDNG9GDYXnicTvK6wWnc";
		const _candidates_numeric_ucKh = 2.2710931100540215;
		const _suggestSimilar_function_Wuph = await suggestSimilar(_word_string_dLAW, _candidates_numeric_ucKh)


	});

	it('test for suggestSimilar', async () => {

		const _startsWith_function_EuQH = () => { };
		const _slice_function_djQZ = () => { };
		const _length_boolean_Nrso = true;
		const _word_object_PzVi = {
			"startsWith": _startsWith_function_EuQH,
		"slice": _slice_function_djQZ,
		"length": _length_boolean_Nrso
	}
		const _anon_string_SMkN = "8fl2";
		const _candidates_array_iRqW = [_anon_string_SMkN]
		const _suggestSimilar_function_HGvX = await suggestSimilar(_word_object_PzVi, _candidates_array_iRqW)


	});

	it('test for suggestSimilar', async () => {

		const _word_string_SJNo = "jyX1PDufcrx387XHWmv79kYLkcIcGKas1PYSl3wnx91GiAKaQCFHJCfQNKXq1dXd7C";
		const _candidates_numeric_rTwr = 2.9884679669035545;
		const _suggestSimilar_function_GtRh = await suggestSimilar(_word_string_SJNo, _candidates_numeric_rTwr)


	});

	it('test for suggestSimilar', async () => {

		const _startsWith_function_EExB = () => { };
		const _anon_string_nfkX = "f2S0OqNNARQnzf8iMDVlboYBvldO53qnyzZHC4aiVB1MJ0wr5lRJBFTrSLshzG7L5ztDMmUXdjA1qMVS6LJBYOURwTbwvHdSK";
		const _slice_array_qXJY = [_anon_string_nfkX]
		const _length_object_ZaCc = {
		
	}
		const _word_object_QwEe = {
			"startsWith": _startsWith_function_EExB,
		"slice": _slice_array_qXJY,
		"length": _length_object_ZaCc
	}
		const _candidates_numeric_gFty = -2.5949980002413;
		const _suggestSimilar_function_PmpD = await suggestSimilar(_word_object_QwEe, _candidates_numeric_gFty)


	});
})