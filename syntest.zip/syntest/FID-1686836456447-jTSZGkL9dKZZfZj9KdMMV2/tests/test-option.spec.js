describe('option', () => {
	const {splitOptionFlags} = require("../../benchmark/commanderjs/lib/option.js");
	const {Option} = require("../../benchmark/commanderjs/lib/option.js");

	it('test for option', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:191:0:::205:1:::4197:4797
		const _split_function_nXtE = () => { };
		const _flags_object_TLCS = {
			"split": _split_function_nXtE
	}
		const _splitOptionFlags_function_cTlO = await splitOptionFlags(_flags_object_TLCS)


	});

	it('test for option', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:13:2:::35:3:::241:1305
		const _anon_string_UJir = "xSFy7FbH";
		const _flags_array_Kpii = [_anon_string_UJir]
		const _description_function_jlqC = () => { };
		const _Option_object_adUK = new Option(_flags_array_Kpii, _description_function_jlqC)
		const _arg_undefined_Bsdx = undefined;
		const _is_function_XISW = await _Option_object_adUK.is(_arg_undefined_Bsdx)
		const _fn_boolean_HpEe = true;
		const _argParser_function_dWqR = await _Option_object_adUK.argParser(_fn_boolean_HpEe)


	});

	it('test for option', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:71:2:::74:3:::2033:2093
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:83:2:::86:3:::2251:2345
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:197:2:::197:89:::4461:4548
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:27:6:::27:50:::1052:1096
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:200:2:::203:3:::4660:4761
		const _flags_string_NfQe = "4B6GmprKHg9FUt839xVFpua9X3oA1LmSd2VRAPqTO";
		const _description_string_kNdD = "4TlAvi2CqWexMmBdW";
		const _Option_object_gACq = new Option(_flags_string_NfQe, _description_string_kNdD)
		const _fn_object_uygF = {
		
	}
		const _argParser_function_sHqO = await _Option_object_gACq.argParser(_fn_object_uygF)
		const _Assignment_boolean_TLbF = true;
		const _makeOptionMandatory_function_VXxc = await _Option_object_gACq.makeOptionMandatory(_Assignment_boolean_TLbF)


	});

	it('test for option', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:119:2:::131:3:::2850:3196
		const _flags_string_wKBw = "5ORPtWQxe2Ss6nTi7t7Dlvx0zbChHyf4C5YYDaFrJgRrMLPhgNK2BdvHUvVo1dw3zhei8";
		const _description_boolean_iJVk = false;
		const _Option_object_jVcf = new Option(_flags_string_wKBw, _description_boolean_iJVk)
		const _fn_function_IQOf = () => { };
		const _argParser_function_RFkk = await _Option_object_jVcf.argParser(_fn_function_IQOf)
		const _Assignment_boolean_JGRM = true;
		const _makeOptionMandatory_function_UZCP = await _Option_object_jVcf.makeOptionMandatory(_Assignment_boolean_JGRM)
		const _includes_function_fPSz = () => { };
		const _join_function_KaUb = () => { };
		const _values_object_CqkD = {
			"includes": _includes_function_fPSz,
		"join": _join_function_KaUb
	}
		const _choices_function_gXUa = await _Option_object_jVcf.choices(_values_object_CqkD)
		const _includes_function_dOur = () => { };
		const _join_function_PJgr = () => { };
		const _values_object_xVwZ = {
			"includes": _includes_function_dOur,
		"join": _join_function_PJgr
	}
		const _choices_function_GQnf = await _Option_object_jVcf.choices(_values_object_xVwZ)


	});

	it('test for option', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:45:2:::49:3:::1503:1632
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:139:2:::144:3:::3266:3389
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:141:6:::141:42:::3302:3338
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:140:4:::142:5:::3279:3344
		const _flags_string_QUeg = "tOcUq5k53bNkmpkZm";
		const _description_boolean_EJwE = false;
		const _Option_object_hoCw = new Option(_flags_string_QUeg, _description_boolean_EJwE)
		const _name_function_qcEh = await _Option_object_hoCw.name()
		const _value_object_rRRp = {
		
	}
		const _anon_string_XJlg = "Y3WKgFOWNuKfCRRTXBUUuxX54uyX6N";
		const _description_array_Axro = [_anon_string_XJlg]
		const _default_function_QssL = await _Option_object_hoCw.default(_value_object_rRRp, _description_array_Axro)
		const _fn_string_jgMF = "qqgxky4Gxtwlw2196pfx5ExwWVVNZTJHlP8avWfYW9uPU9aZJQjdR8rB0sXggR";
		const _argParser_function_UmQg = await _Option_object_hoCw.argParser(_fn_string_jgMF)


	});

	it('test for option', async () => {

		const _includes_string_sggt = "cA8Jf4cd74XYa9x4Uqgu5ukbKy7AKoXPiHWxOqZoAyqRdKMSh6TX9rXyXxNL";
		const _flags_object_uyFl = {
			"includes": _includes_string_sggt
	}
		const _description_boolean_qqLQ = false;
		const _Option_object_xzXL = new Option(_flags_object_uyFl, _description_boolean_qqLQ)
		const _arg_boolean_lwPU = false;
		const _is_function_EkZy = await _Option_object_xzXL.is(_arg_boolean_lwPU)
		const _Assignment_boolean_uplc = true;
		const _makeOptionMandatory_function_rLus = await _Option_object_xzXL.makeOptionMandatory(_Assignment_boolean_uplc)


	});

	it('test for option', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:59:2:::62:3:::1820:1876
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:95:2:::98:3:::2450:2520
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:104:2:::110:3:::2556:2725
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:106:6:::106:21:::2664:2679
		const _flags_string_bxSE = "lRXd";
		const _description_null_FVPv = null;
		const _Option_object_aEhp = new Option(_flags_string_bxSE, _description_null_FVPv)
		const _value_numeric_irhY = -8.040404332081232;
		const _description_object_Ohsl = {
		
	}
		const _default_function_wrdL = await _Option_object_aEhp.default(_value_numeric_irhY, _description_object_Ohsl)
		const _Assignment_boolean_ZRCw = true;
		const _hideHelp_function_IEQG = await _Option_object_aEhp.hideHelp(_Assignment_boolean_ZRCw)
		const _name_string_FiFY = "9Pz25AqelBkXdW4ASdvOe1PCbwiCHXY6wiSXNkeBGsDaDR8p3ELJ3b4HQnRQ9bDKctA1UFKeFGYSwFBe4YNiHv61l4UJltUvY";
		const _env_function_jZQl = await _Option_object_aEhp.env(_name_string_FiFY)
		const _anon_string_qswh = "kQR4FS9DUWyl5eglR3zEDIqI2TPT5NA08voCqHRigRWQTbgg";
		const _value_array_MWZo = [_anon_string_qswh]
		const _concat_function_fGnA = () => { };
		const _previous_object_oZlm = {
			"concat": _concat_function_fGnA
	}
		const __concatValue_function_jbth = await _Option_object_aEhp._concatValue(_value_array_MWZo, _previous_object_oZlm)
		const _value_function_nJSw = () => { };
		const _previous_string_LxMK = "h3zR6NTUfs8Vdih3TgQHcC1X3iQzRZA4wqV6ZLRbIkbnCiDk8oDlTURr1L81n27jgMm7CJOtPy71hHdolUifDfwm2nR0iLdXLY";
		const __concatValue_function_yNJp = await _Option_object_aEhp._concatValue(_value_function_nJSw, _previous_string_LxMK)


	});

	it('test for option', async () => {

		const _flags_undefined_cRma = undefined;
		const _description_string_aLJy = "zoacHJynBdP3KYHQt0eMvlBHUxSBK2wYy9FvpHN62SAsjhu3FK4XcJF8iaKhncoqKsSiDkMG7ywiDkWDHbQv";
		const _Option_object_tnYD = new Option(_flags_undefined_cRma, _description_string_aLJy)
		const _Assignment_boolean_UJYh = false;
		const _hideHelp_function_qltD = await _Option_object_tnYD.hideHelp(_Assignment_boolean_UJYh)
		const _anon_string_DlLj = "TMhG4vYhbyVJnu5wV9I6bk5bl7N93IlRMgD2mRDi5naUm";
		const _values_array_BwQn = [_anon_string_DlLj]
		const _choices_function_XvaZ = await _Option_object_tnYD.choices(_values_array_BwQn)
		const _name_function_UrSw = () => { };
		const _env_function_aPww = await _Option_object_tnYD.env(_name_function_UrSw)


	});

	it('test for option', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:154:2:::156:3:::3548:3624
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:179:0:::183:1:::3954:4091
		const _flags_string_JxvK = "fNGcrccYq8IXjmW1wbfpCrsbtl9ACVAWVprMAPbBzNXXNYUMZ2e";
		const _description_boolean_xPMW = true;
		const _Option_object_pWRw = new Option(_flags_string_JxvK, _description_boolean_xPMW)
		const _values_string_IqtS = "ICU";
		const _choices_function_gJVk = await _Option_object_pWRw.choices(_values_string_IqtS)
		const _value_object_XBFE = {
		
	}
		const _concat_function_DLou = () => { };
		const _previous_object_VIGO = {
			"concat": _concat_function_DLou
	}
		const __concatValue_function_lBsw = await _Option_object_pWRw._concatValue(_value_object_XBFE, _previous_object_VIGO)
		const _Assignment_boolean_hPZa = true;
		const _hideHelp_function_QGXF = await _Option_object_pWRw.hideHelp(_Assignment_boolean_hPZa)
		const _attributeName_function_kZSL = await _Option_object_pWRw.attributeName()


	});

	it('test for option', async () => {
		// Covers objective: /Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:166:2:::168:3:::3765:3830
		const _flags_string_wfRK = "bvCD52ymBbWMv3PwDiFerMIuUKS5rRVnVUzyLtJlVxBcQC2q4CYWGPoz5F";
		const _description_null_AWpM = null;
		const _Option_object_SOAn = new Option(_flags_string_wfRK, _description_null_AWpM)
		const _arg_string_joWz = "348qUxJkAF2MWeCKzCgctrnXwGVPoDffz0CEHYkotbYSDp";
		const _is_function_QxTU = await _Option_object_SOAn.is(_arg_string_joWz)
		const _includes_function_LCdD = () => { };
		const _join_function_UGCq = () => { };
		const _values_object_kKor = {
			"includes": _includes_function_LCdD,
		"join": _join_function_UGCq
	}
		const _choices_function_cryK = await _Option_object_SOAn.choices(_values_object_kKor)
		const _fn_numeric_OhdG = 3.8015104469090577;
		const _argParser_function_OCWT = await _Option_object_SOAn.argParser(_fn_numeric_OhdG)


	});

	it('test for option', async () => {
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:105:4:::107:5:::2592:2685
		const _flags_string_jKEJ = "coTuBUSUI97WhNfJRX2ePl2";
		const _description_string_NhYZ = "LqIq2U9hsA6d8hCgT6pXSavxNLwU1gtZzWOKPVpWA16cgM6jsvno5Z244NzdnwRbbTfoFnSNAxL2maiNlpEOP9qHcubH";
		const _Option_object_KkQl = new Option(_flags_string_jKEJ, _description_string_NhYZ)
		const _name_function_koxF = await _Option_object_KkQl.name()
		const _value_string_VglW = "Q1tYohypVeJi3rP8MaVIpn7yBREXw4RldlkKoaSn3ijjiDhAnff7jbeaxn5EzDvJw4FHJBFc1wzVZtRmDpGOIrJv464";
		const _anon_string_EOfl = "eJsT6y2o2ozzzr2bTutlx5u138t1RTyXgItSsMA5Ax1wOGhkWlMlfjSwJd4rcQFw0Cr5NftkIXzT2mfhhmOCnwnX53F";
		const _previous_array_njlj = [_anon_string_EOfl]
		const __concatValue_function_mIxh = await _Option_object_KkQl._concatValue(_value_string_VglW, _previous_array_njlj)
		const _Assignment_boolean_yNwV = false;
		const _makeOptionMandatory_function_mJva = await _Option_object_KkQl.makeOptionMandatory(_Assignment_boolean_yNwV)
		const _name_function_UPrL = await _Option_object_KkQl.name()


	});

	it('test for option', async () => {

		const _flags_undefined_rJUi = undefined;
		const _splitOptionFlags_function_sQni = await splitOptionFlags(_flags_undefined_rJUi)


	});

	it('test for option', async () => {

		const _flags_null_FXXT = null;
		const _splitOptionFlags_function_qzQH = await splitOptionFlags(_flags_null_FXXT)


	});

	it('test for option', async () => {

		const _flags_null_xWav = null;
		const _description_string_FRAw = "fEh";
		const _Option_object_OPBZ = new Option(_flags_null_xWav, _description_string_FRAw)
		const _attributeName_function_KOlY = await _Option_object_OPBZ.attributeName()
		const _Assignment_boolean_Phaf = false;
		const _hideHelp_function_EAbf = await _Option_object_OPBZ.hideHelp(_Assignment_boolean_Phaf)


	});

	it('test for option', async () => {
		// Covers objective: placeholder:::/Users/dimitrist/Documents/git/syntest/syntest-javascript-benchmark/benchmark/commanderjs/lib/option.js:26:4:::28:5:::1029:1102
		const _flags_string_uUCM = "";
		const _description_boolean_wdrt = true;
		const _Option_object_ZgZi = new Option(_flags_string_uUCM, _description_boolean_wdrt)
		const _Assignment_boolean_CtRy = true;
		const _makeOptionMandatory_function_rSbG = await _Option_object_ZgZi.makeOptionMandatory(_Assignment_boolean_CtRy)


	});

	it('test for option', async () => {

		const _flags_string_sgsd = "";
		const _description_boolean_YaLS = true;
		const _Option_object_lVHN = new Option(_flags_string_sgsd, _description_boolean_YaLS)
		const _name_function_YXBE = await _Option_object_lVHN.name()
		const _Assignment_boolean_gVFW = false;
		const _makeOptionMandatory_function_MoBT = await _Option_object_lVHN.makeOptionMandatory(_Assignment_boolean_gVFW)
		const _fn_boolean_QqwT = true;
		const _argParser_function_CpYm = await _Option_object_lVHN.argParser(_fn_boolean_QqwT)


	});
})