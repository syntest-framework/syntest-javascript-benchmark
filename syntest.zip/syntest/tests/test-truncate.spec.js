import truncate from "../../lodash/truncate.js";
import chai from 'chai'
import chaiAsPromised from 'chai-as-promised'
const expect = chai.expect;
chai.use(chaiAsPromised);

describe('truncate', () => {
	it('test for truncate', async () => {
		const _string_array_SNFH = []
		const _options_numeric_QWxo = -9.348430303126852;
		const _truncate_function_sUwh = await truncate(_string_array_SNFH, _options_numeric_QWxo)

		expect(JSON.parse(JSON.stringify(_string_array_SNFH))).to.deep.equal([])
		expect(_truncate_function_sUwh).to.equal("")
	});

	it('test for truncate', async () => {
		const _string_numeric_pzLN = -8.62418116051423;
		const _options_array_MsdN = []
		const _truncate_function_XkHI = await truncate(_string_numeric_pzLN, _options_array_MsdN)

		expect(JSON.parse(JSON.stringify(_options_array_MsdN))).to.deep.equal([])
		expect(_truncate_function_XkHI).to.equal("...")
	});

	it('test for truncate', async () => {
		const _string_function_stWG = () => { };
		const _options_object_ZMFK = {
		
	}
		const _truncate_function_Ytwj = await truncate(_string_function_stWG, _options_object_ZMFK)

		expect(JSON.parse(JSON.stringify(_options_object_ZMFK))).to.deep.equal({})
		expect(_truncate_function_Ytwj).to.equal("function _string_function_s...")
	});

	it('test for truncate', async () => {
		const _string_object_ZTYF = {
		
	}
		const _options_array_fhDM = []
		const _truncate_function_KeBP = await truncate(_string_object_ZTYF, _options_array_fhDM)

		expect(JSON.parse(JSON.stringify(_options_array_fhDM))).to.deep.equal([])
		expect(JSON.parse(JSON.stringify(_string_object_ZTYF))).to.deep.equal({})
		expect(_truncate_function_KeBP).to.equal("...")
	});
})